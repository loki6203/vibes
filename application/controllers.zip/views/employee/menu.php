<!doctype html>
<html lang="en">
   <head>
      <meta charset="utf-8" />
      <title>::Vibho Employee Solutions::</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta content="Vibho Employee Solutions" name="description" />
      <meta content="Vibho Employee Solutions" name="author" />
      <!-- App favicon -->

      <script>
         var base_url ='<?php echo base_url(); ?>';
      </script>
      <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/admin/images/VIBES Final-sm.png">
      <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
      <link href="<?php echo base_url(); ?>assets/admin/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
      <!-- DataTables -->
      <link href="<?php echo base_url(); ?>assets/admin/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
      <link href="<?php echo base_url(); ?>assets/admin/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
      <!-- Sweet Alert-->
      <link href="<?php echo base_url(); ?>assets/admin/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
      <!-- Bootstrap Css -->
      <link href="<?php echo base_url(); ?>assets/admin/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
      <!-- Icons Css -->
      <link href="<?php echo base_url(); ?>assets/admin/css/icons.min.css" rel="stylesheet" type="text/css" />
      <link href="<?php echo base_url(); ?>assets/admin/libs/dropzone/min/dropzone.min.css" rel="stylesheet" type="text/css" />
      <!-- App Css-->
      <link href="<?php echo base_url(); ?>assets/admin/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
      <link href="<?php echo base_url(); ?>assets/admin/css/zebra_datepicker.min.css" rel="stylesheet" type="text/css" />
      <script src="<?php echo base_url(); ?>assets/js/jquery-3.6.0.js"></script>
      <script src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script>
      <script src="<?php echo base_url(); ?>assets/admin/js/jquery.validate.min.js"></script>
      <script src="<?php echo base_url(); ?>assets/admin/js/sweetalert2@10.js"></script>
      <script src="<?php echo base_url(); ?>assets/admin/js/sweetalert.min.js"></script>
      <script src="<?php echo base_url(); ?>assets/admin/js/zebra_datepicker.min.js"></script>
      <?php
         $success=($this->session->flashdata('success')!='')?strip_tags($this->session->flashdata('success')):((isset($success) && $success!='')?$success:'');
         $error=($this->session->flashdata('failed')!='')?strip_tags($this->session->flashdata('failed')):((isset($failed) && $failed!='')?$failed:'');
         $notif=($this->session->flashdata('notif')!='')?strip_tags($this->session->flashdata('notif')):((isset($notif) && $notif!='')?$notif:'');
         ?>
      <script type="text/javascript">
         $(document).ready(function(){
             <?php
            if($success!=''){
            ?>
             Swal.fire({
                icon: 'success',
                title: '<?php echo $success;?>',
             });
             
             <?php
            }
            if($error!=''){
            ?>
             Swal.fire({
                 title: "<?php echo $error;?>",
                 icon: "error",
             });
             <?php
            }
            if($notif!=''){
            ?>
             Swal.fire({
                 title: "<?php echo $notif;?>",
                 icon: "error",
             });
             <?php
            }
            ?>
         });
      </script>
   </head>
   <body data-sidebar="dark">
      <!-- Begin page -->
      <div id="layout-wrapper">
      <header id="page-topbar">
         <div class="navbar-header">
            <div class="d-flex">
               <!-- LOGO -->
               <div class="navbar-brand-box p-0">
                  <a href="<?php echo base_url(); ?>employee/dashboard" class="logo top-ad-logo logo-dark">
                  <span class="logo-sm">
                  <img src="<?php echo base_url(); ?>assets/admin/images/logo.svg" alt="" height="22">
                  </span>
                  <span class="logo-lg">
                  <img src="<?php echo base_url(); ?>assets/admin/images/VIBHO-New-Logo-R3.png" alt="" height="17">
                  </span>
                  </a>
                  <a href="<?php echo base_url(); ?>employee/dashboard" class="logo top-ad-logo logo-light">
                  <span class="logo-sm">
                  <img src="<?php echo base_url(); ?>assets/admin/images/logo-sm.png" alt="" height="22">
                  </span>
                  <span class="logo-lg">
                  <img src="<?php echo base_url(); ?>assets/admin/images/VIBES Final.png" alt="" height="18">
                  </span>
                  </a>
               </div>
             
            </div>
            <div class="d-flex">
               <div class="dropdown d-inline-block d-lg-none ml-2">
                  <button type="button" class="btn header-item noti-icon waves-effect" id="page-header-search-dropdown"
                     data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="mdi mdi-magnify"></i>
                  </button>
                  <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right p-0"
                     aria-labelledby="page-header-search-dropdown">
                     <form class="p-3">
                        <div class="form-group m-0">
                           <div class="input-group">
                              <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient's username">
                              <div class="input-group-append">
                                 <button class="btn btn-primary" type="submit"><i class="mdi mdi-magnify"></i></button>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
               <div class="dropdown d-inline-block">
                   <a href="https://support.vibhotech.com/" class="btn btn-danger" target="_blank"><i class='fas fa-headset align-middle mr-1' style='font-size:19px'></i><span>Support </span></a>
                  <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     <?php 
                        $emp_id = $this->session->userdata('emp_id');
                        $get_emp_details = $this->db->query("SELECT `emp_id`, `fname`, `lname`, `emp_code` FROM `employees` WHERE `emp_id`=$emp_id")->row_array();
                        $emp_name = ucfirst($get_emp_details['fname']).' '.ucfirst($get_emp_details['lname']);
                        echo $emp_name;
                     ?>&nbsp;&nbsp;<i class="fa fa-caret-down" aria-hidden="true"></i>
                  </button>
                  <div class="dropdown-menu dropdown-menu-right">
                     <!-- item-->
                     <?php 
                        if($this->session->userdata('role_id')!='Admin' && $this->session->userdata('role_id')!=''){
                          $role_id=$this->session->userdata('role_id'); 
                          $GetRoleName=$this->db->query("SELECT `roles_id`, `role_name`, `is_active`, `created_at`, `updated_at` FROM `roles` WHERE `roles_id`='$role_id'")->row_array();
                        ?>
                        <a class="dropdown-item" href="<?php echo base_url(); ?>admin/dashboard"><i class="fa fa-toggle-on" aria-hidden="true"></i> Switch To <?php echo ucfirst(@$GetRoleName['role_name']); ?></a>
                     <?php } ?>
                     <a class="dropdown-item" href="<?php echo base_url(); ?>employee/change_password"><i class="mdi mdi-lock font-size-17 align-middle mr-1"></i> Change Password</a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item text-danger" href="<?php echo base_url(); ?>employee/logout"><i class="mdi mdi-power font-size-17 align-middle mr-1 text-danger"></i> Logout</a>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- ========== Left Sidebar Start ========== -->
      <div class="vertical-menu">
         <div class="menu-toggle-sidebar">
                  <span>MENU</span>
                  <button type="button" class="btn btn-sm waves-effect" id="vertical-menu-btn">
                     <svg width="19" height="14" viewBox="0 0 19 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 1H18" stroke="black" stroke-width="1.8" stroke-linecap="round"/>
                        <path d="M9.5 6.66797L18 6.66797" stroke="black" stroke-width="1.8" stroke-linecap="round"/>
                        <path d="M3 12.332H18" stroke="black" stroke-width="1.8" stroke-linecap="round"/>
                     </svg>
                  </button>
               </div>
         <div data-simplebar class="h-100">
            <!--- Sidemenu -->
            <div id="sidebar-menu">
               <!-- Left Menu Start -->
               <ul class="metismenu list-unstyled" id="side-menu">
                  <li>
                     <a href="<?php echo base_url(); ?>employee/dashboard" class="waves-effect">
                     <div class="menu-item-left">
                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M16.1136 8.11364V5.93182C16.1136 5.35316 15.8838 4.79821 15.4746 4.38904C15.0654 3.97987 14.5105 3.75 13.9318 3.75H5.93182C5.35316 3.75 4.79821 3.97987 4.38904 4.38904C3.97987 4.79821 3.75 5.35316 3.75 5.93182V13.9318C3.75 14.5105 3.97987 15.0654 4.38904 15.4746C4.79821 15.8838 5.35316 16.1136 5.93182 16.1136H8.11364M16.1136 8.11364H17.5682C18.1468 8.11364 18.7018 8.34351 19.111 8.75268C19.5201 9.16185 19.75 9.7168 19.75 10.2955V17.5682C19.75 18.1468 19.5201 18.7018 19.111 19.111C18.7018 19.5201 18.1468 19.75 17.5682 19.75H10.2955C9.7168 19.75 9.16185 19.5201 8.75268 19.111C8.34351 18.7018 8.11364 18.1468 8.11364 17.5682V16.1136M16.1136 8.11364H10.2955C9.7168 8.11364 9.16185 8.34351 8.75268 8.75268C8.34351 9.16185 8.11364 9.7168 8.11364 10.2955V16.1136" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Dashboard</span>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a href="<?php echo base_url(); ?>employee/my_profile" <?php if($active_menu=='my_profile'){echo 'class="active_menu"';}?>>
                     <div class="menu-item-left">
                     <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M13.7812 5.25C13.7812 6.12024 13.4355 6.95484 12.8202 7.57019C12.2048 8.18555 11.3702 8.53125 10.5 8.53125C9.62974 8.53125 8.79514 8.18555 8.17979 7.57019C7.56443 6.95484 7.21873 6.12024 7.21873 5.25C7.21873 4.37976 7.56443 3.54516 8.17979 2.92981C8.79514 2.31445 9.62974 1.96875 10.5 1.96875C11.3702 1.96875 12.2048 2.31445 12.8202 2.92981C13.4355 3.54516 13.7812 4.37976 13.7812 5.25ZM3.93835 17.6033C3.96647 15.8816 4.67015 14.2399 5.89763 13.0323C7.12512 11.8247 8.77806 11.1479 10.5 11.1479C12.2219 11.1479 13.8748 11.8247 15.1023 13.0323C16.3298 14.2399 17.0335 15.8816 17.0616 17.6033C15.0031 18.5472 12.7646 19.0343 10.5 19.0312C8.15848 19.0312 5.93598 18.5203 3.93835 17.6033Z" stroke="black" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
                              </svg>
                              <span>My Profile</span>
                     </div>
                     </a>
                  </li>
                 
                  <li>
                     <a href="<?php echo base_url(); ?>employee/timesheet" <?php if($active_menu=='timesheet'){echo 'class="active_menu"';}?> >
                     <div class="menu-item-left">
                              <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M4.75 5.59142V4.75C4.75 4.17813 4.97718 3.62968 5.38155 3.2253C5.78593 2.82093 6.33438 2.59375 6.90625 2.59375H14.0937C14.6656 2.59375 15.2141 2.82093 15.6184 3.2253C16.0228 3.62968 16.25 4.17813 16.25 4.75V5.59142M4.75 5.59142C4.97521 5.51187 5.21671 5.46875 5.46875 5.46875H15.5312C15.7833 5.46875 16.0248 5.51187 16.25 5.59142M4.75 5.59142C4.3295 5.74009 3.96544 6.0155 3.70799 6.3797C3.45054 6.74391 3.31237 7.17899 3.3125 7.625V8.46642M16.25 5.59142C16.6705 5.74009 17.0346 6.0155 17.292 6.3797C17.5495 6.74391 17.6876 7.17899 17.6875 7.625V8.46642M17.6875 8.46642C17.4566 8.38495 17.2136 8.34347 16.9687 8.34375H4.03125C3.77921 8.34375 3.53771 8.38688 3.3125 8.46642M17.6875 8.46642C18.108 8.61509 18.4721 8.8905 18.7295 9.2547C18.987 9.61891 19.1251 10.054 19.125 10.5V16.25C19.125 16.8219 18.8978 17.3703 18.4934 17.7747C18.0891 18.1791 17.5406 18.4062 16.9687 18.4062H4.03125C3.45938 18.4062 2.91093 18.1791 2.50655 17.7747C2.10218 17.3703 1.875 16.8219 1.875 16.25V10.5C1.875 9.56083 2.47492 8.76254 3.3125 8.46642" stroke="black" stroke-width="0.958333" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                     <span>Timesheet</span>
                     </div>
                  </a>
                  </li>
                  <li>
                     <a href="<?php echo base_url(); ?>employee/timesheet_report" <?php if($active_menu=='timesheet_report'){echo 'class="active_menu"';}?> >
                     <div class="menu-item-left">
                           <svg width="21" height="24" viewBox="0 0 21 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M18.0833 13.823V11.3615C18.0833 10.5221 17.7238 9.71711 17.0838 9.12358C16.4438 8.53006 15.5758 8.19662 14.6708 8.19662H13.1541C12.8524 8.19662 12.5631 8.08548 12.3498 7.88764C12.1365 7.6898 12.0166 7.42147 12.0166 7.14168V5.73509C12.0166 4.89572 11.6571 4.09073 11.0171 3.49721C10.3772 2.90369 9.50918 2.57025 8.60413 2.57025H6.70829M6.70829 14.5263H14.2916M6.70829 17.3395H10.5M8.98329 2.57025H4.05413C3.42623 2.57025 2.91663 3.04287 2.91663 3.6252V19.801C2.91663 20.3833 3.42623 20.856 4.05413 20.856H16.9458C17.5737 20.856 18.0833 20.3833 18.0833 19.801V11.0098C18.0833 8.7715 17.1245 6.62487 15.418 5.04214C13.7114 3.45942 11.3968 2.57025 8.98329 2.57025V2.57025Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                     <span>Timesheet Report</span>
                     </div>
                  </a>
                  </li>
                  <li>
                     <a href="<?php echo base_url(); ?>employee/payslips" <?php if($active_menu=='payslips'){echo 'class="active_menu"';}?> >
                     <div class="menu-item-left">
                     <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M17.7188 12.3812V16.1C17.7188 17.0572 17.0302 17.8815 16.0808 18.0075C14.2547 18.2499 12.3918 18.375 10.5 18.375C8.6083 18.375 6.74542 18.2499 4.9193 18.0075C3.96992 17.8815 3.2813 17.0572 3.2813 16.1V12.3812M17.7188 12.3812C17.9266 12.2007 18.0928 11.9773 18.2061 11.7264C18.3194 11.4756 18.377 11.2031 18.375 10.9279V7.61775C18.375 6.67188 17.703 5.85463 16.7677 5.71463C15.7766 5.56624 14.7805 5.45329 13.7813 5.376M17.7188 12.3812C17.549 12.5256 17.3513 12.6394 17.1299 12.7137C14.9916 13.4232 12.753 13.7837 10.5 13.7812C8.18305 13.7813 5.95442 13.4059 3.87017 12.7137C3.65427 12.6419 3.45431 12.529 3.2813 12.3812M3.2813 12.3812C3.07352 12.2007 2.90729 11.9773 2.79401 11.7264C2.68073 11.4756 2.62309 11.2031 2.62505 10.9279V7.61775C2.62505 6.67188 3.29705 5.85463 4.23242 5.71463C5.22353 5.56624 6.21963 5.45329 7.2188 5.376M13.7813 5.376V4.59375C13.7813 4.07161 13.5739 3.57085 13.2047 3.20163C12.8355 2.83242 12.3347 2.625 11.8125 2.625H9.18755C8.6654 2.625 8.16464 2.83242 7.79543 3.20163C7.42622 3.57085 7.2188 4.07161 7.2188 4.59375V5.376M13.7813 5.376C11.5971 5.20719 9.40304 5.20719 7.2188 5.376M10.5 11.1562H10.507V11.1633H10.5V11.1562Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                     <span>Payslips</span>
                     </div>
                  </a>
                  </li>
                  <li>
                     <a href="<?php echo base_url(); ?>employee/other_documents" <?php if($active_menu=='other_documents'){echo 'class="active_menu"';}?> >
                     <div class="menu-item-left">
                           <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M4.75 5.59142V4.75C4.75 4.17813 4.97718 3.62968 5.38155 3.2253C5.78593 2.82093 6.33438 2.59375 6.90625 2.59375H14.0937C14.6656 2.59375 15.2141 2.82093 15.6184 3.2253C16.0228 3.62968 16.25 4.17813 16.25 4.75V5.59142M4.75 5.59142C4.97521 5.51187 5.21671 5.46875 5.46875 5.46875H15.5312C15.7833 5.46875 16.0248 5.51187 16.25 5.59142M4.75 5.59142C4.3295 5.74009 3.96544 6.0155 3.70799 6.3797C3.45054 6.74391 3.31237 7.17899 3.3125 7.625V8.46642M16.25 5.59142C16.6705 5.74009 17.0346 6.0155 17.292 6.3797C17.5495 6.74391 17.6876 7.17899 17.6875 7.625V8.46642M17.6875 8.46642C17.4566 8.38495 17.2136 8.34347 16.9687 8.34375H4.03125C3.77921 8.34375 3.53771 8.38688 3.3125 8.46642M17.6875 8.46642C18.108 8.61509 18.4721 8.8905 18.7295 9.2547C18.987 9.61891 19.1251 10.054 19.125 10.5V16.25C19.125 16.8219 18.8978 17.3703 18.4934 17.7747C18.0891 18.1791 17.5406 18.4062 16.9687 18.4062H4.03125C3.45938 18.4062 2.91093 18.1791 2.50655 17.7747C2.10218 17.3703 1.875 16.8219 1.875 16.25V10.5C1.875 9.56083 2.47492 8.76254 3.3125 8.46642" stroke="black" stroke-width="0.958333" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Other Documents</span>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a href="<?php echo base_url(); ?>employee/leaves" <?php if($active_menu=='leaves'){echo 'class="active_menu"';}?> >
                     <div class="menu-item-left">
                           <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M11 7.40122V11.22M11 1C8.73574 3.18965 5.72027 4.39061 2.598 4.34623C2.20074 5.57871 1.99887 6.86779 2 8.16497C2 13.8595 5.824 18.6436 11 20C16.176 18.6436 20 13.8595 20 8.16497C20 6.83096 19.79 5.54786 19.402 4.34623H19.25C16.054 4.34623 13.15 3.07434 11 1V1ZM11 14.2749H11.008V14.2831H11V14.2749Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Leaves</span>
                        </div>
                  </a>
                  </li>
                  <li>
                     <a href="<?php echo base_url(); ?>employee/public_holidays" <?php if($active_menu=='public_holidays'){echo 'class="active_menu"';}?> >
                     <div class="menu-item-left">
                           <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M8 5.74952V13.9995M14 7.99952V16.2495M14.503 19.7475L19.378 17.3105C19.759 17.1205 20 16.7305 20 16.3045V3.81952C20 2.98352 19.12 2.43952 18.372 2.81352L14.503 4.74752C14.186 4.90652 13.813 4.90652 13.497 4.74752L8.503 2.25152C8.34682 2.17346 8.17461 2.13281 8 2.13281C7.82539 2.13281 7.65318 2.17346 7.497 2.25152L2.622 4.68852C2.24 4.87952 2 5.26952 2 5.69452V18.1795C2 19.0155 2.88 19.5595 3.628 19.1855L7.497 17.2515C7.814 17.0925 8.187 17.0925 8.503 17.2515L13.497 19.7485C13.814 19.9065 14.187 19.9065 14.503 19.7485V19.7475Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                     <span>Public Holidays</span> 
                     </div>
                  </a>
                  </li>
                  <?php $type = $this->session->userdata('type');
                     if($type==4){ ?>
                  <li>
                     <a href="<?php echo base_url(); ?>employee/recruitment" <?php if($active_menu=='recruitment'){echo 'class="active_menu"';}?> target="_blank">
                     <div class="menu-item-left">
                           <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M16.153 15.9786C17.3467 16.0794 18.5476 15.9205 19.6782 15.5121C19.7214 14.9622 19.613 14.4109 19.3657 13.922C19.1184 13.4331 18.7422 13.0266 18.2806 12.7495C17.819 12.4724 17.291 12.336 16.7576 12.356C16.2241 12.3761 15.7071 12.5519 15.2663 12.863M16.1521 15.9776L16.153 16.0078C16.153 16.2269 16.1417 16.4431 16.1181 16.6564C14.4081 17.6704 12.4705 18.2024 10.499 18.1991C8.45418 18.1991 6.53466 17.6381 4.87993 16.6564C4.8557 16.431 4.84406 16.2044 4.84506 15.9776M16.153 15.9776C16.1493 14.8738 15.8418 13.7939 15.2663 12.864C14.7554 12.036 14.0508 11.3545 13.2175 10.8826C12.3842 10.4107 11.4492 10.1637 10.499 10.1643C9.54901 10.1638 8.61421 10.4109 7.7811 10.8828C6.94799 11.3547 6.24348 12.0361 5.73274 12.864C5.29193 12.5532 4.77499 12.3776 4.24171 12.3577C3.70843 12.3378 3.18057 12.4742 2.71917 12.7513C2.25778 13.0284 1.88169 13.4348 1.63439 13.9235C1.38709 14.4122 1.27868 14.9633 1.3217 15.513C2.45147 15.9237 3.65267 16.0821 4.84601 15.9776C4.84939 14.8739 5.15662 13.794 5.73179 12.864M13.326 4.32085C13.326 5.09574 13.0282 5.83889 12.498 6.38683C11.9678 6.93476 11.2488 7.24258 10.499 7.24258C9.74927 7.24258 9.03021 6.93476 8.50005 6.38683C7.96989 5.83889 7.67205 5.09574 7.67205 4.32085C7.67205 3.54595 7.96989 2.8028 8.50005 2.25487C9.03021 1.70693 9.74927 1.39911 10.499 1.39911C11.2488 1.39911 11.9678 1.70693 12.498 2.25487C13.0282 2.8028 13.326 3.54595 13.326 4.32085ZM18.98 7.24258C18.98 7.53035 18.9251 7.8153 18.8186 8.08116C18.712 8.34702 18.5559 8.58859 18.359 8.79207C18.1621 8.99555 17.9284 9.15696 17.6711 9.26708C17.4139 9.3772 17.1382 9.43388 16.8597 9.43388C16.5813 9.43388 16.3056 9.3772 16.0484 9.26708C15.7911 9.15696 15.5574 8.99555 15.3605 8.79207C15.1636 8.58859 15.0074 8.34702 14.9009 8.08116C14.7943 7.8153 14.7395 7.53035 14.7395 7.24258C14.7395 6.66141 14.9629 6.10405 15.3605 5.6931C15.7581 5.28215 16.2974 5.05128 16.8597 5.05128C17.4221 5.05128 17.9614 5.28215 18.359 5.6931C18.7566 6.10405 18.98 6.66141 18.98 7.24258ZM6.25856 7.24258C6.25856 7.53035 6.20371 7.8153 6.09716 8.08116C5.99061 8.34702 5.83443 8.58859 5.63755 8.79207C5.44067 8.99555 5.20694 9.15696 4.9497 9.26708C4.69246 9.3772 4.41675 9.43388 4.13832 9.43388C3.85989 9.43388 3.58418 9.3772 3.32694 9.26708C3.0697 9.15696 2.83597 8.99555 2.63908 8.79207C2.4422 8.58859 2.28603 8.34702 2.17947 8.08116C2.07292 7.8153 2.01808 7.53035 2.01808 7.24258C2.01808 6.66141 2.24146 6.10405 2.63908 5.6931C3.03671 5.28215 3.576 5.05128 4.13832 5.05128C4.70064 5.05128 5.23993 5.28215 5.63755 5.6931C6.03517 6.10405 6.25856 6.66141 6.25856 7.24258Z" stroke="black" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                     <span>Recruitment </span>
                     </div>
                  </a>
                  </li>
               <?php } ?>
               <?php
                    $mnth =date("m");
                    $mnthName =date("M");
                    $ChkMonthData = $this->db->query("SELECT `confirmation_of_employment_id`, `emp_id`, `emp_data`, `is_generated`, `created_at`, `updated_at` FROM `confirmation_of_employment` WHERE `emp_id`=$emp_id AND MONTH(`created_at`)='$mnth'")->num_rows();
                ?>
               <li>
                    <a href="#" onclick="ConfirmationofEmployment();">
                    <div class="menu-item-left">
                           <svg width="21" height="24" viewBox="0 0 21 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M18.0833 13.823V11.3615C18.0833 10.5221 17.7238 9.71711 17.0838 9.12358C16.4438 8.53006 15.5758 8.19662 14.6708 8.19662H13.1541C12.8524 8.19662 12.5631 8.08548 12.3498 7.88764C12.1365 7.6898 12.0166 7.42147 12.0166 7.14168V5.73509C12.0166 4.89572 11.6571 4.09073 11.0171 3.49721C10.3772 2.90369 9.50918 2.57025 8.60413 2.57025H6.70829M6.70829 14.5263H14.2916M6.70829 17.3395H10.5M8.98329 2.57025H4.05413C3.42623 2.57025 2.91663 3.04287 2.91663 3.6252V19.801C2.91663 20.3833 3.42623 20.856 4.05413 20.856H16.9458C17.5737 20.856 18.0833 20.3833 18.0833 19.801V11.0098C18.0833 8.7715 17.1245 6.62487 15.418 5.04214C13.7114 3.45942 11.3968 2.57025 8.98329 2.57025V2.57025Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                    <span>Confirmation of Employment </span>
                    </div>
                  </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>employee/notifications">
                    <div class="menu-item-left">
                           <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M1.75 10H18.25M1.75 13.75H18.25M1.75 17.5H18.25M3.625 2.5H16.375C16.8723 2.5 17.3492 2.69754 17.7008 3.04917C18.0525 3.40081 18.25 3.87772 18.25 4.375C18.25 4.87228 18.0525 5.34919 17.7008 5.70083C17.3492 6.05246 16.8723 6.25 16.375 6.25H3.625C3.12772 6.25 2.65081 6.05246 2.29917 5.70083C1.94754 5.34919 1.75 4.87228 1.75 4.375C1.75 3.87772 1.94754 3.40081 2.29917 3.04917C2.65081 2.69754 3.12772 2.5 3.625 2.5V2.5Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                    <span>Notifications </span>
                    </div>
                  </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>employee/claims">
                    <div class="menu-item-left">
                           <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M1.75 10H18.25M1.75 13.75H18.25M1.75 17.5H18.25M3.625 2.5H16.375C16.8723 2.5 17.3492 2.69754 17.7008 3.04917C18.0525 3.40081 18.25 3.87772 18.25 4.375C18.25 4.87228 18.0525 5.34919 17.7008 5.70083C17.3492 6.05246 16.8723 6.25 16.375 6.25H3.625C3.12772 6.25 2.65081 6.05246 2.29917 5.70083C1.94754 5.34919 1.75 4.87228 1.75 4.375C1.75 3.87772 1.94754 3.40081 2.29917 3.04917C2.65081 2.69754 3.12772 2.5 3.625 2.5V2.5Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                    <span>Claims </span>
                    </div>
                  </a>
                </li>
               </ul>
            </div>
            <!-- Sidebar -->
         </div>
      </div>
      <!-- Left Sidebar End -->

    <script>
    function ConfirmationofEmployment()
    {
       var ChkMonthData='<?php echo $ChkMonthData; ?>';
       Swal.fire({
         text: "Are you sure want to generate the confirmation of employment ?",
         icon: 'warning',
         showCancelButton: true,
         confirmButtonColor: '#3085d6',
         cancelButtonColor: '#d33',
         confirmButtonText: 'Yes'
          }).then((result) => {
                if (result.isConfirmed)
                {
                    if(ChkMonthData==0){
                      window.open('<?php echo base_url();?>employee/ConfirmationofEmployment/', '_blank');
                    }else{
                      window.location='<?php echo base_url();?>employee/ConfirmationofEmployment/';
                    }
              }
       });
    }
    </script>