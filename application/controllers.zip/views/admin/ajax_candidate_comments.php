<div class="indidual-div-previos-comments">
<?php if(!empty($comments)){$i=1;foreach ($comments as $cmnts) { ?>
<div class="previos-comments" style="background-color: #d8d7d7">
  <p><?php echo $i; ?>) Comments: <?php echo $cmnts['comments']; ?></p>
  <p>Status:
  	<?php 
  		if($cmnts['status']=='source_applied'){
			echo 'source/applied';
		}else if($cmnts['status']=='internal_interview'){
			echo 'internal interview';
		}else if($cmnts['status']=='client_interview'){
			echo 'client interview';
		}else{
			echo $cmnts['status'];
		}
   ?>
   </p>
  <p>Date: <?php echo DD_M_YY_h_i_s($cmnts['date']); ?></p>
</div>
<?php $i++;} } ?>
</div>