<!doctype html>
<html lang="en">
   <head>
      <meta charset="utf-8" />
      <title>::Vibho Employee Solutions::</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta content="Vibho Employee Solutions" name="description" />
      <meta content="Vibho Employee Solutions" name="author" />
      <!-- App favicon -->

      <script>
         var base_url ='<?php echo base_url(); ?>';
      </script>
      <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/admin/images/VIBES Final-sm.png">
      
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
      <link href="<?php echo base_url(); ?>assets/admin/libs/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
      <!-- DataTables -->
      <link href="<?php echo base_url(); ?>assets/admin/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
      <link href="<?php echo base_url(); ?>assets/admin/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
      <!-- Sweet Alert-->
      <link href="<?php echo base_url(); ?>assets/admin/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
      <!-- Bootstrap Css -->
      <link href="<?php echo base_url(); ?>assets/admin/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
      <!-- Icons Css -->
      <link href="<?php echo base_url(); ?>assets/admin/css/icons.min.css" rel="stylesheet" type="text/css" />
      <link href="<?php echo base_url(); ?>assets/admin/libs/dropzone/min/dropzone.min.css" rel="stylesheet" type="text/css" />
      <!-- App Css-->
      <link href="<?php echo base_url(); ?>assets/admin/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
      <link href="<?php echo base_url(); ?>assets/admin/css/zebra_datepicker.min.css" rel="stylesheet" type="text/css" />
      <script src="<?php echo base_url(); ?>assets/js/jquery-3.6.0.js"></script>
      <script src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script>
      <script src="<?php echo base_url(); ?>assets/admin/js/jquery.validate.min.js"></script>
      <script src="<?php echo base_url(); ?>assets/admin/js/sweetalert2@10.js"></script>
      <script src="<?php echo base_url(); ?>assets/admin/js/sweetalert.min.js"></script>
       <script src="<?php echo base_url(); ?>assets/admin/js/zebra_datepicker.min.js"></script>
      <?php
         $success=($this->session->flashdata('success')!='')?strip_tags($this->session->flashdata('success')):((isset($success) && $success!='')?$success:'');
         $error=($this->session->flashdata('failed')!='')?strip_tags($this->session->flashdata('failed')):((isset($failed) && $failed!='')?$failed:'');
         $notif=($this->session->flashdata('notif')!='')?strip_tags($this->session->flashdata('notif')):((isset($notif) && $notif!='')?$notif:'');
         ?>
      <script type="text/javascript">
         $(document).ready(function(){
             <?php
            if($success!=''){
            ?>
             Swal.fire({
                icon: 'success',
                title: '<?php echo $success;?>',
             });
             
             <?php
            }
            if($error!=''){
            ?>
             Swal.fire({
                 title: "<?php echo $error;?>",
                 icon: "error",
             });
             <?php
            }
            if($notif!=''){
            ?>
             Swal.fire({
                 title: "<?php echo $notif;?>",
                 icon: "error",
             });
             <?php
            }
            ?>
         });
      </script>
   </head>
   <body data-sidebar="dark">
      <!-- Begin page -->
      <div id="layout-wrapper">
      <header id="page-topbar">
         <div class="navbar-header">
            <div class="d-flex">
               <!-- LOGO -->
               <div class="navbar-brand-box p-0">
                  <a href="<?php echo base_url(); ?>admin/dashboard" class="logo top-ad-logo logo-dark">
                  <span class="logo-sm">
                  <img src="<?php echo base_url(); ?>assets/admin/images/logo.svg" alt="" height="22">
                  </span>
                  <span class="logo-lg">
                  <img src="<?php echo base_url(); ?>assets/admin/images/VIBHO-New-Logo-R3.png" alt="" height="17">
                  </span>
                  </a>
                  <a href="<?php echo base_url(); ?>admin/dashboard" class="logo top-ad-logo logo-light">
                  <span class="logo-sm">
                  <img src="<?php echo base_url(); ?>assets/admin/images/logo-sm.png" alt="" height="22">
                  </span>
                  <span class="logo-lg">
                  <img src="<?php echo base_url(); ?>assets/admin/images/VIBES Final.png" alt="" height="18">
                  </span>
                  </a>
               </div>
               
            </div>
            <div class="d-flex">
               <div class="dropdown d-inline-block d-lg-none ml-2">
                  <button type="button" class="btn header-item noti-icon waves-effect" id="page-header-search-dropdown"
                     data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="mdi mdi-magnify"></i>
                  </button>
                  <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right p-0"
                     aria-labelledby="page-header-search-dropdown">
                     <form class="p-3">
                        <div class="form-group m-0">
                           <div class="input-group">
                              <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient's username">
                              <div class="input-group-append">
                                 <button class="btn btn-primary" type="submit"><i class="mdi mdi-magnify"></i></button>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
               <div class="dropdown d-inline-block">
                   <a href="https://support.vibhotech.com/" class="btn btn-danger" target="_blank"><i class='fas fa-headset align-middle mr-1' style='font-size:19px'></i><span>Support </span></a>
                  <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                     data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     <?php 
                        $emp_id = $this->session->userdata('emp_id');
                        $role_id=$this->session->userdata('role_id');
                        $GetRoleName=$this->db->query("SELECT `roles_id`, `role_name`, `is_active`, `created_at`, `updated_at` FROM `roles` WHERE `roles_id`='$role_id'")->row_array();
                        if($emp_id!=''){
                            $get_emp_details = $this->db->query("SELECT `emp_id`, `fname`, `lname`, `emp_code` FROM `employees` WHERE `emp_id`=$emp_id")->row_array();
                            $emp_name = ucfirst($get_emp_details['fname']).' '.ucfirst($get_emp_details['lname']);
                            echo $emp_name.' ('.(ucfirst($GetRoleName['role_name']).')');
                        }else{
                            echo "Admin";
                        }
                     ?>
                  &nbsp;&nbsp;<i class="fa fa-caret-down" aria-hidden="true"></i>
                  </button>
                  <div class="dropdown-menu dropdown-menu-right">
                     <!-- item-->
                      <?php if($this->session->userdata('role_id')!='Admin'){ ?>
                        <a class="dropdown-item" href="<?php echo base_url(); ?>employee/dashboard"><i class="fa fa-toggle-on" aria-hidden="true"></i> Switch To Employee</a>
                     <?php } ?>
                     <a class="dropdown-item" href="<?php echo base_url(); ?>admin/change_password"><i class="mdi mdi-lock font-size-17 align-middle mr-1"></i> Change Password</a>
                     <div class="dropdown-divider"></div>
                     <a class="dropdown-item text-danger" href="<?php echo base_url(); ?>admin/logout"><i class="mdi mdi-power font-size-17 align-middle mr-1 text-danger"></i> Logout</a>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- ========== Left Sidebar Start ========== -->
      <div class="vertical-menu">
      <div class="menu-toggle-sidebar">
                  <span>MENU</span>
                  <button type="button" class="btn btn-sm waves-effect" id="vertical-menu-btn">
                     <svg width="19" height="14" viewBox="0 0 19 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 1H18" stroke="black" stroke-width="1.8" stroke-linecap="round"/>
                        <path d="M9.5 6.66797L18 6.66797" stroke="black" stroke-width="1.8" stroke-linecap="round"/>
                        <path d="M3 12.332H18" stroke="black" stroke-width="1.8" stroke-linecap="round"/>
                     </svg>
                  </button>
               </div>
         <div data-simplebar class="h-100">
            <!--- Sidemenu -->
            <div id="sidebar-menu">
               <!-- Left Menu Start -->
              <?php if($this->session->userdata('role_id')=='Admin'){ ?>
               <ul class="metismenu list-unstyled" id="side-menu">
                  <li>
                     <a href="<?php echo base_url(); ?>admin/dashboard" class="waves-effect">
                        <div class="menu-item-left">
                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M16.1136 8.11364V5.93182C16.1136 5.35316 15.8838 4.79821 15.4746 4.38904C15.0654 3.97987 14.5105 3.75 13.9318 3.75H5.93182C5.35316 3.75 4.79821 3.97987 4.38904 4.38904C3.97987 4.79821 3.75 5.35316 3.75 5.93182V13.9318C3.75 14.5105 3.97987 15.0654 4.38904 15.4746C4.79821 15.8838 5.35316 16.1136 5.93182 16.1136H8.11364M16.1136 8.11364H17.5682C18.1468 8.11364 18.7018 8.34351 19.111 8.75268C19.5201 9.16185 19.75 9.7168 19.75 10.2955V17.5682C19.75 18.1468 19.5201 18.7018 19.111 19.111C18.7018 19.5201 18.1468 19.75 17.5682 19.75H10.2955C9.7168 19.75 9.16185 19.5201 8.75268 19.111C8.34351 18.7018 8.11364 18.1468 8.11364 17.5682V16.1136M16.1136 8.11364H10.2955C9.7168 8.11364 9.16185 8.34351 8.75268 8.75268C8.34351 9.16185 8.11364 9.7168 8.11364 10.2955V16.1136" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Dashboard</span>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <div class="menu-item-left">
                           <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M16.153 15.9786C17.3467 16.0794 18.5476 15.9205 19.6782 15.5121C19.7214 14.9622 19.613 14.4109 19.3657 13.922C19.1184 13.4331 18.7422 13.0266 18.2806 12.7495C17.819 12.4724 17.291 12.336 16.7576 12.356C16.2241 12.3761 15.7071 12.5519 15.2663 12.863M16.1521 15.9776L16.153 16.0078C16.153 16.2269 16.1417 16.4431 16.1181 16.6564C14.4081 17.6704 12.4705 18.2024 10.499 18.1991C8.45418 18.1991 6.53466 17.6381 4.87993 16.6564C4.8557 16.431 4.84406 16.2044 4.84506 15.9776M16.153 15.9776C16.1493 14.8738 15.8418 13.7939 15.2663 12.864C14.7554 12.036 14.0508 11.3545 13.2175 10.8826C12.3842 10.4107 11.4492 10.1637 10.499 10.1643C9.54901 10.1638 8.61421 10.4109 7.7811 10.8828C6.94799 11.3547 6.24348 12.0361 5.73274 12.864C5.29193 12.5532 4.77499 12.3776 4.24171 12.3577C3.70843 12.3378 3.18057 12.4742 2.71917 12.7513C2.25778 13.0284 1.88169 13.4348 1.63439 13.9235C1.38709 14.4122 1.27868 14.9633 1.3217 15.513C2.45147 15.9237 3.65267 16.0821 4.84601 15.9776C4.84939 14.8739 5.15662 13.794 5.73179 12.864M13.326 4.32085C13.326 5.09574 13.0282 5.83889 12.498 6.38683C11.9678 6.93476 11.2488 7.24258 10.499 7.24258C9.74927 7.24258 9.03021 6.93476 8.50005 6.38683C7.96989 5.83889 7.67205 5.09574 7.67205 4.32085C7.67205 3.54595 7.96989 2.8028 8.50005 2.25487C9.03021 1.70693 9.74927 1.39911 10.499 1.39911C11.2488 1.39911 11.9678 1.70693 12.498 2.25487C13.0282 2.8028 13.326 3.54595 13.326 4.32085ZM18.98 7.24258C18.98 7.53035 18.9251 7.8153 18.8186 8.08116C18.712 8.34702 18.5559 8.58859 18.359 8.79207C18.1621 8.99555 17.9284 9.15696 17.6711 9.26708C17.4139 9.3772 17.1382 9.43388 16.8597 9.43388C16.5813 9.43388 16.3056 9.3772 16.0484 9.26708C15.7911 9.15696 15.5574 8.99555 15.3605 8.79207C15.1636 8.58859 15.0074 8.34702 14.9009 8.08116C14.7943 7.8153 14.7395 7.53035 14.7395 7.24258C14.7395 6.66141 14.9629 6.10405 15.3605 5.6931C15.7581 5.28215 16.2974 5.05128 16.8597 5.05128C17.4221 5.05128 17.9614 5.28215 18.359 5.6931C18.7566 6.10405 18.98 6.66141 18.98 7.24258ZM6.25856 7.24258C6.25856 7.53035 6.20371 7.8153 6.09716 8.08116C5.99061 8.34702 5.83443 8.58859 5.63755 8.79207C5.44067 8.99555 5.20694 9.15696 4.9497 9.26708C4.69246 9.3772 4.41675 9.43388 4.13832 9.43388C3.85989 9.43388 3.58418 9.3772 3.32694 9.26708C3.0697 9.15696 2.83597 8.99555 2.63908 8.79207C2.4422 8.58859 2.28603 8.34702 2.17947 8.08116C2.07292 7.8153 2.01808 7.53035 2.01808 7.24258C2.01808 6.66141 2.24146 6.10405 2.63908 5.6931C3.03671 5.28215 3.576 5.05128 4.13832 5.05128C4.70064 5.05128 5.23993 5.28215 5.63755 5.6931C6.03517 6.10405 6.25856 6.66141 6.25856 7.24258Z" stroke="black" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Employee </span>
                        </div>
                     </a>
                     <ul class="sub-menu" aria-expanded="false">
                        <li>
                           <a href="<?php echo base_url(); ?>admin/employee"<?php if($active_menu=='employee'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                                 <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M13.7812 5.25C13.7812 6.12024 13.4355 6.95484 12.8202 7.57019C12.2048 8.18555 11.3702 8.53125 10.5 8.53125C9.62974 8.53125 8.79514 8.18555 8.17979 7.57019C7.56443 6.95484 7.21873 6.12024 7.21873 5.25C7.21873 4.37976 7.56443 3.54516 8.17979 2.92981C8.79514 2.31445 9.62974 1.96875 10.5 1.96875C11.3702 1.96875 12.2048 2.31445 12.8202 2.92981C13.4355 3.54516 13.7812 4.37976 13.7812 5.25ZM3.93835 17.6033C3.96647 15.8816 4.67015 14.2399 5.89763 13.0323C7.12512 11.8247 8.77806 11.1479 10.5 11.1479C12.2219 11.1479 13.8748 11.8247 15.1023 13.0323C16.3298 14.2399 17.0335 15.8816 17.0616 17.6033C15.0031 18.5472 12.7646 19.0343 10.5 19.0312C8.15848 19.0312 5.93598 18.5203 3.93835 17.6033Z" stroke="black" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
                                 </svg>
                                 <span>Employee Management</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/asset"<?php if($active_menu=='asset'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                                 <svg width="21" height="22" viewBox="0 0 21 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M6.86361 3.24352C7.99401 2.49625 9.30574 2.06919 10.6594 2.00772C12.0131 1.94626 13.3581 2.25269 14.5516 2.89445C15.7451 3.53621 16.7424 4.48932 17.4375 5.65249C18.1327 6.81567 18.4997 8.14545 18.4996 9.50052C18.4996 12.4205 17.9436 15.2095 16.9316 17.7685M4.74161 5.36452C3.92917 6.59072 3.49708 8.0296 3.49961 9.50052C3.50197 10.9135 3.10318 12.2982 2.34961 13.4935M4.33861 17.0525C6.21563 14.9856 7.2537 12.2926 7.24961 9.50052C7.24961 8.50596 7.6447 7.55214 8.34796 6.84887C9.05122 6.14561 10.005 5.75052 10.9996 5.75052C11.9942 5.75052 12.948 6.14561 13.6513 6.84887C14.3545 7.55214 14.7496 8.50596 14.7496 9.50052C14.7496 10.0275 14.7286 10.5495 14.6856 11.0655M10.9996 9.50052C11.0052 13.0766 9.72784 16.5361 7.39961 19.2505M14.0326 14.6545C13.4911 16.5513 12.6524 18.3503 11.5476 19.9845" stroke="black" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
                                 </svg>
                                 <span>Asset</span>
                              </div>
                           </a>
                        </li>
                         <li>
                           <a href="<?php echo base_url(); ?>admin/employee_performance" <?php if($active_menu=='employee_performance'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                                 <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1.96875 13.7812L6.48287 9.26712C6.66569 9.08431 6.88273 8.93929 7.12159 8.84035C7.36045 8.74141 7.61646 8.69048 7.875 8.69048C8.13354 8.69048 8.38955 8.74141 8.62841 8.84035C8.86727 8.93929 9.08431 9.08431 9.26712 9.26712L13.7812 13.7812M12.4688 12.4688L13.7016 11.2359C13.8844 11.0531 14.1015 10.908 14.3403 10.8091C14.5792 10.7102 14.8352 10.6592 15.0938 10.6592C15.3523 10.6592 15.6083 10.7102 15.8472 10.8091C16.086 10.908 16.3031 11.0531 16.4859 11.2359L19.0312 13.7812M3.28125 17.0625H17.7188C18.0668 17.0625 18.4007 16.9242 18.6468 16.6781C18.893 16.4319 19.0312 16.0981 19.0312 15.75V5.25C19.0312 4.9019 18.893 4.56806 18.6468 4.32192C18.4007 4.07578 18.0668 3.9375 17.7188 3.9375H3.28125C2.93315 3.9375 2.59931 4.07578 2.35317 4.32192C2.10703 4.56806 1.96875 4.9019 1.96875 5.25V15.75C1.96875 16.0981 2.10703 16.4319 2.35317 16.6781C2.59931 16.9242 2.93315 17.0625 3.28125 17.0625ZM12.4688 7.21875H12.4758V7.22575H12.4688V7.21875ZM12.7969 7.21875C12.7969 7.30577 12.7623 7.38923 12.7008 7.45077C12.6392 7.51231 12.5558 7.54688 12.4688 7.54688C12.3817 7.54688 12.2983 7.51231 12.2367 7.45077C12.1752 7.38923 12.1406 7.30577 12.1406 7.21875C12.1406 7.13173 12.1752 7.04827 12.2367 6.98673C12.2983 6.9252 12.3817 6.89062 12.4688 6.89062C12.5558 6.89062 12.6392 6.9252 12.7008 6.98673C12.7623 7.04827 12.7969 7.13173 12.7969 7.21875V7.21875Z" stroke="black" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                 <span>Employee Annual Performance</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/employee_documents" <?php if($active_menu=='employee_documents'){echo 'class="active_menu"';}?> >
                           <div class="menu-item-left">
                              <svg width="21" height="18" viewBox="0 0 21 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M6.9205 3.75H18.375M6.9205 9H18.375M6.9205 14.25H18.375M2.62504 3.75H2.63173V3.758H2.62504V3.75ZM2.983 3.75C2.983 3.84946 2.94529 3.94484 2.87816 4.01516C2.81103 4.08549 2.71998 4.125 2.62504 4.125C2.53011 4.125 2.43906 4.08549 2.37193 4.01516C2.3048 3.94484 2.26709 3.84946 2.26709 3.75C2.26709 3.65054 2.3048 3.55516 2.37193 3.48484C2.43906 3.41451 2.53011 3.375 2.62504 3.375C2.71998 3.375 2.81103 3.41451 2.87816 3.48484C2.94529 3.55516 2.983 3.65054 2.983 3.75ZM2.62504 9H2.63173V9.008H2.62504V9ZM2.983 9C2.983 9.09946 2.94529 9.19484 2.87816 9.26517C2.81103 9.33549 2.71998 9.375 2.62504 9.375C2.53011 9.375 2.43906 9.33549 2.37193 9.26517C2.3048 9.19484 2.26709 9.09946 2.26709 9C2.26709 8.90054 2.3048 8.80516 2.37193 8.73483C2.43906 8.66451 2.53011 8.625 2.62504 8.625C2.71998 8.625 2.81103 8.66451 2.87816 8.73483C2.94529 8.80516 2.983 8.90054 2.983 9V9ZM2.62504 14.25H2.63173V14.258H2.62504V14.25ZM2.983 14.25C2.983 14.3495 2.94529 14.4448 2.87816 14.5152C2.81103 14.5855 2.71998 14.625 2.62504 14.625C2.53011 14.625 2.43906 14.5855 2.37193 14.5152C2.3048 14.4448 2.26709 14.3495 2.26709 14.25C2.26709 14.1505 2.3048 14.0552 2.37193 13.9848C2.43906 13.9145 2.53011 13.875 2.62504 13.875C2.71998 13.875 2.81103 13.9145 2.87816 13.9848C2.94529 14.0552 2.983 14.1505 2.983 14.25Z" stroke="black" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
                              </svg>
                              <span>Employee Checks</span>
                           </div>
                        </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/employee_compensation"<?php if($active_menu=='employee'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                                 <svg width="21" height="24" viewBox="0 0 21 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M18.0833 13.823V11.3615C18.0833 10.5221 17.7238 9.71711 17.0838 9.12358C16.4438 8.53006 15.5758 8.19662 14.6708 8.19662H13.1541C12.8524 8.19662 12.5631 8.08548 12.3498 7.88764C12.1365 7.6898 12.0166 7.42147 12.0166 7.14168V5.73509C12.0166 4.89572 11.6571 4.09073 11.0171 3.49721C10.3772 2.90369 9.50918 2.57025 8.60413 2.57025H6.70829M6.70829 14.5263H14.2916M6.70829 17.3395H10.5M8.98329 2.57025H4.05413C3.42623 2.57025 2.91663 3.04287 2.91663 3.6252V19.801C2.91663 20.3833 3.42623 20.856 4.05413 20.856H16.9458C17.5737 20.856 18.0833 20.3833 18.0833 19.801V11.0098C18.0833 8.7715 17.1245 6.62487 15.418 5.04214C13.7114 3.45942 11.3968 2.57025 8.98329 2.57025V2.57025Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                                 <span>Employee Compensation</span>
                              </div>
                           </a>
                        </li>
                     </ul>
                  </li>
                 
                  <li>
                     <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <div class="menu-item-left">
                           <svg width="21" height="24" viewBox="0 0 21 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M18.0833 13.823V11.3615C18.0833 10.5221 17.7238 9.71711 17.0838 9.12358C16.4438 8.53006 15.5758 8.19662 14.6708 8.19662H13.1541C12.8524 8.19662 12.5631 8.08548 12.3498 7.88764C12.1365 7.6898 12.0166 7.42147 12.0166 7.14168V5.73509C12.0166 4.89572 11.6571 4.09073 11.0171 3.49721C10.3772 2.90369 9.50918 2.57025 8.60413 2.57025H6.70829M6.70829 14.5263H14.2916M6.70829 17.3395H10.5M8.98329 2.57025H4.05413C3.42623 2.57025 2.91663 3.04287 2.91663 3.6252V19.801C2.91663 20.3833 3.42623 20.856 4.05413 20.856H16.9458C17.5737 20.856 18.0833 20.3833 18.0833 19.801V11.0098C18.0833 8.7715 17.1245 6.62487 15.418 5.04214C13.7114 3.45942 11.3968 2.57025 8.98329 2.57025V2.57025Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Timesheet Management </span>
                        </div>
                     </a>
                     <ul class="sub-menu" aria-expanded="false">
                         <li>
                           <a href="<?php echo base_url(); ?>admin/timesheet" <?php if($active_menu=='timesheet'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M4.75 5.59142V4.75C4.75 4.17813 4.97718 3.62968 5.38155 3.2253C5.78593 2.82093 6.33438 2.59375 6.90625 2.59375H14.0937C14.6656 2.59375 15.2141 2.82093 15.6184 3.2253C16.0228 3.62968 16.25 4.17813 16.25 4.75V5.59142M4.75 5.59142C4.97521 5.51187 5.21671 5.46875 5.46875 5.46875H15.5312C15.7833 5.46875 16.0248 5.51187 16.25 5.59142M4.75 5.59142C4.3295 5.74009 3.96544 6.0155 3.70799 6.3797C3.45054 6.74391 3.31237 7.17899 3.3125 7.625V8.46642M16.25 5.59142C16.6705 5.74009 17.0346 6.0155 17.292 6.3797C17.5495 6.74391 17.6876 7.17899 17.6875 7.625V8.46642M17.6875 8.46642C17.4566 8.38495 17.2136 8.34347 16.9687 8.34375H4.03125C3.77921 8.34375 3.53771 8.38688 3.3125 8.46642M17.6875 8.46642C18.108 8.61509 18.4721 8.8905 18.7295 9.2547C18.987 9.61891 19.1251 10.054 19.125 10.5V16.25C19.125 16.8219 18.8978 17.3703 18.4934 17.7747C18.0891 18.1791 17.5406 18.4062 16.9687 18.4062H4.03125C3.45938 18.4062 2.91093 18.1791 2.50655 17.7747C2.10218 17.3703 1.875 16.8219 1.875 16.25V10.5C1.875 9.56083 2.47492 8.76254 3.3125 8.46642" stroke="black" stroke-width="0.958333" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                                 <span>Timesheet</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/timesheet_freezed" <?php if($active_menu=='timesheet_freezed'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M4.75 5.59142V4.75C4.75 4.17813 4.97718 3.62968 5.38155 3.2253C5.78593 2.82093 6.33438 2.59375 6.90625 2.59375H14.0937C14.6656 2.59375 15.2141 2.82093 15.6184 3.2253C16.0228 3.62968 16.25 4.17813 16.25 4.75V5.59142M4.75 5.59142C4.97521 5.51187 5.21671 5.46875 5.46875 5.46875H15.5312C15.7833 5.46875 16.0248 5.51187 16.25 5.59142M4.75 5.59142C4.3295 5.74009 3.96544 6.0155 3.70799 6.3797C3.45054 6.74391 3.31237 7.17899 3.3125 7.625V8.46642M16.25 5.59142C16.6705 5.74009 17.0346 6.0155 17.292 6.3797C17.5495 6.74391 17.6876 7.17899 17.6875 7.625V8.46642M17.6875 8.46642C17.4566 8.38495 17.2136 8.34347 16.9687 8.34375H4.03125C3.77921 8.34375 3.53771 8.38688 3.3125 8.46642M17.6875 8.46642C18.108 8.61509 18.4721 8.8905 18.7295 9.2547C18.987 9.61891 19.1251 10.054 19.125 10.5V16.25C19.125 16.8219 18.8978 17.3703 18.4934 17.7747C18.0891 18.1791 17.5406 18.4062 16.9687 18.4062H4.03125C3.45938 18.4062 2.91093 18.1791 2.50655 17.7747C2.10218 17.3703 1.875 16.8219 1.875 16.25V10.5C1.875 9.56083 2.47492 8.76254 3.3125 8.46642" stroke="black" stroke-width="0.958333" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                                 <span>Freeze Timesheet</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/item_management" <?php if($active_menu=='item_management'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M16.1136 8.11364V5.93182C16.1136 5.35316 15.8838 4.79821 15.4746 4.38904C15.0654 3.97987 14.5105 3.75 13.9318 3.75H5.93182C5.35316 3.75 4.79821 3.97987 4.38904 4.38904C3.97987 4.79821 3.75 5.35316 3.75 5.93182V13.9318C3.75 14.5105 3.97987 15.0654 4.38904 15.4746C4.79821 15.8838 5.35316 16.1136 5.93182 16.1136H8.11364M16.1136 8.11364H17.5682C18.1468 8.11364 18.7018 8.34351 19.111 8.75268C19.5201 9.16185 19.75 9.7168 19.75 10.2955V17.5682C19.75 18.1468 19.5201 18.7018 19.111 19.111C18.7018 19.5201 18.1468 19.75 17.5682 19.75H10.2955C9.7168 19.75 9.16185 19.5201 8.75268 19.111C8.34351 18.7018 8.11364 18.1468 8.11364 17.5682V16.1136M16.1136 8.11364H10.2955C9.7168 8.11364 9.16185 8.34351 8.75268 8.75268C8.34351 9.16185 8.11364 9.7168 8.11364 10.2955V16.1136" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                                 <span>Task Management</span>
                              </div>
                           </a>
                        </li>
                     </ul>
                  </li>
                  
                  <li>
                     <a href="<?php echo base_url(); ?>admin/payslips" <?php if($active_menu=='payslips'){echo 'class="active_menu direct_menu"';}?> >
                        <div class="menu-item-left">
                           <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M17.7188 12.3812V16.1C17.7188 17.0572 17.0302 17.8815 16.0808 18.0075C14.2547 18.2499 12.3918 18.375 10.5 18.375C8.6083 18.375 6.74542 18.2499 4.9193 18.0075C3.96992 17.8815 3.2813 17.0572 3.2813 16.1V12.3812M17.7188 12.3812C17.9266 12.2007 18.0928 11.9773 18.2061 11.7264C18.3194 11.4756 18.377 11.2031 18.375 10.9279V7.61775C18.375 6.67188 17.703 5.85463 16.7677 5.71463C15.7766 5.56624 14.7805 5.45329 13.7813 5.376M17.7188 12.3812C17.549 12.5256 17.3513 12.6394 17.1299 12.7137C14.9916 13.4232 12.753 13.7837 10.5 13.7812C8.18305 13.7813 5.95442 13.4059 3.87017 12.7137C3.65427 12.6419 3.45431 12.529 3.2813 12.3812M3.2813 12.3812C3.07352 12.2007 2.90729 11.9773 2.79401 11.7264C2.68073 11.4756 2.62309 11.2031 2.62505 10.9279V7.61775C2.62505 6.67188 3.29705 5.85463 4.23242 5.71463C5.22353 5.56624 6.21963 5.45329 7.2188 5.376M13.7813 5.376V4.59375C13.7813 4.07161 13.5739 3.57085 13.2047 3.20163C12.8355 2.83242 12.3347 2.625 11.8125 2.625H9.18755C8.6654 2.625 8.16464 2.83242 7.79543 3.20163C7.42622 3.57085 7.2188 4.07161 7.2188 4.59375V5.376M13.7813 5.376C11.5971 5.20719 9.40304 5.20719 7.2188 5.376M10.5 11.1562H10.507V11.1633H10.5V11.1562Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Payslip Management</span>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a href="<?php echo base_url(); ?>admin/other_documents" <?php if($active_menu=='other_documents'){echo 'class="active_menu direct_menu"';}?> >
                        <div class="menu-item-left">
                           <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M4.75 5.59142V4.75C4.75 4.17813 4.97718 3.62968 5.38155 3.2253C5.78593 2.82093 6.33438 2.59375 6.90625 2.59375H14.0937C14.6656 2.59375 15.2141 2.82093 15.6184 3.2253C16.0228 3.62968 16.25 4.17813 16.25 4.75V5.59142M4.75 5.59142C4.97521 5.51187 5.21671 5.46875 5.46875 5.46875H15.5312C15.7833 5.46875 16.0248 5.51187 16.25 5.59142M4.75 5.59142C4.3295 5.74009 3.96544 6.0155 3.70799 6.3797C3.45054 6.74391 3.31237 7.17899 3.3125 7.625V8.46642M16.25 5.59142C16.6705 5.74009 17.0346 6.0155 17.292 6.3797C17.5495 6.74391 17.6876 7.17899 17.6875 7.625V8.46642M17.6875 8.46642C17.4566 8.38495 17.2136 8.34347 16.9687 8.34375H4.03125C3.77921 8.34375 3.53771 8.38688 3.3125 8.46642M17.6875 8.46642C18.108 8.61509 18.4721 8.8905 18.7295 9.2547C18.987 9.61891 19.1251 10.054 19.125 10.5V16.25C19.125 16.8219 18.8978 17.3703 18.4934 17.7747C18.0891 18.1791 17.5406 18.4062 16.9687 18.4062H4.03125C3.45938 18.4062 2.91093 18.1791 2.50655 17.7747C2.10218 17.3703 1.875 16.8219 1.875 16.25V10.5C1.875 9.56083 2.47492 8.76254 3.3125 8.46642" stroke="black" stroke-width="0.958333" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Other Documents</span>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a href="<?php echo base_url(); ?>admin/leaves" <?php if($active_menu=='leaves'){echo 'class="active_menu direct_menu"';}?> >
                        <div class="menu-item-left">
                           <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M11 7.40122V11.22M11 1C8.73574 3.18965 5.72027 4.39061 2.598 4.34623C2.20074 5.57871 1.99887 6.86779 2 8.16497C2 13.8595 5.824 18.6436 11 20C16.176 18.6436 20 13.8595 20 8.16497C20 6.83096 19.79 5.54786 19.402 4.34623H19.25C16.054 4.34623 13.15 3.07434 11 1V1ZM11 14.2749H11.008V14.2831H11V14.2749Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Leaves</span>
                        </div>
                     </a>  
                  </li>
                  <li>
                     <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <div class="menu-item-left">
                           <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M1.75 10H18.25M1.75 13.75H18.25M1.75 17.5H18.25M3.625 2.5H16.375C16.8723 2.5 17.3492 2.69754 17.7008 3.04917C18.0525 3.40081 18.25 3.87772 18.25 4.375C18.25 4.87228 18.0525 5.34919 17.7008 5.70083C17.3492 6.05246 16.8723 6.25 16.375 6.25H3.625C3.12772 6.25 2.65081 6.05246 2.29917 5.70083C1.94754 5.34919 1.75 4.87228 1.75 4.375C1.75 3.87772 1.94754 3.40081 2.29917 3.04917C2.65081 2.69754 3.12772 2.5 3.625 2.5V2.5Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Payroll Management </span>
                        </div>
                     </a>
                     <ul class="sub-menu" aria-expanded="false">
                        <li>
                           <a href="<?php echo base_url(); ?>admin/payroll" <?php if($active_menu=='payroll'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M17.7188 12.3812V16.1C17.7188 17.0572 17.0302 17.8815 16.0808 18.0075C14.2547 18.2499 12.3918 18.375 10.5 18.375C8.6083 18.375 6.74542 18.2499 4.9193 18.0075C3.96992 17.8815 3.2813 17.0572 3.2813 16.1V12.3812M17.7188 12.3812C17.9266 12.2007 18.0928 11.9773 18.2061 11.7264C18.3194 11.4756 18.377 11.2031 18.375 10.9279V7.61775C18.375 6.67188 17.703 5.85463 16.7677 5.71463C15.7766 5.56624 14.7805 5.45329 13.7813 5.376M17.7188 12.3812C17.549 12.5256 17.3513 12.6394 17.1299 12.7137C14.9916 13.4232 12.753 13.7837 10.5 13.7812C8.18305 13.7813 5.95442 13.4059 3.87017 12.7137C3.65427 12.6419 3.45431 12.529 3.2813 12.3812M3.2813 12.3812C3.07352 12.2007 2.90729 11.9773 2.79401 11.7264C2.68073 11.4756 2.62309 11.2031 2.62505 10.9279V7.61775C2.62505 6.67188 3.29705 5.85463 4.23242 5.71463C5.22353 5.56624 6.21963 5.45329 7.2188 5.376M13.7813 5.376V4.59375C13.7813 4.07161 13.5739 3.57085 13.2047 3.20163C12.8355 2.83242 12.3347 2.625 11.8125 2.625H9.18755C8.6654 2.625 8.16464 2.83242 7.79543 3.20163C7.42622 3.57085 7.2188 4.07161 7.2188 4.59375V5.376M13.7813 5.376C11.5971 5.20719 9.40304 5.20719 7.2188 5.376M10.5 11.1562H10.507V11.1633H10.5V11.1562Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                                 <span>Payroll</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/finance_report" <?php if($active_menu=='finance_report'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                                 <svg width="21" height="24" viewBox="0 0 21 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M18.0833 13.823V11.3615C18.0833 10.5221 17.7238 9.71711 17.0838 9.12358C16.4438 8.53006 15.5758 8.19662 14.6708 8.19662H13.1541C12.8524 8.19662 12.5631 8.08548 12.3498 7.88764C12.1365 7.6898 12.0166 7.42147 12.0166 7.14168V5.73509C12.0166 4.89572 11.6571 4.09073 11.0171 3.49721C10.3772 2.90369 9.50918 2.57025 8.60413 2.57025H6.70829M6.70829 14.5263H14.2916M6.70829 17.3395H10.5M8.98329 2.57025H4.05413C3.42623 2.57025 2.91663 3.04287 2.91663 3.6252V19.801C2.91663 20.3833 3.42623 20.856 4.05413 20.856H16.9458C17.5737 20.856 18.0833 20.3833 18.0833 19.801V11.0098C18.0833 8.7715 17.1245 6.62487 15.418 5.04214C13.7114 3.45942 11.3968 2.57025 8.98329 2.57025V2.57025Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                                 </svg>
                                 <span>Finance Reports</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/reports" <?php if($active_menu=='reports'){echo 'class="active_menu"';}?> >
                           <div class="menu-item-left">
                           <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M4.75 5.59142V4.75C4.75 4.17813 4.97718 3.62968 5.38155 3.2253C5.78593 2.82093 6.33438 2.59375 6.90625 2.59375H14.0937C14.6656 2.59375 15.2141 2.82093 15.6184 3.2253C16.0228 3.62968 16.25 4.17813 16.25 4.75V5.59142M4.75 5.59142C4.97521 5.51187 5.21671 5.46875 5.46875 5.46875H15.5312C15.7833 5.46875 16.0248 5.51187 16.25 5.59142M4.75 5.59142C4.3295 5.74009 3.96544 6.0155 3.70799 6.3797C3.45054 6.74391 3.31237 7.17899 3.3125 7.625V8.46642M16.25 5.59142C16.6705 5.74009 17.0346 6.0155 17.292 6.3797C17.5495 6.74391 17.6876 7.17899 17.6875 7.625V8.46642M17.6875 8.46642C17.4566 8.38495 17.2136 8.34347 16.9687 8.34375H4.03125C3.77921 8.34375 3.53771 8.38688 3.3125 8.46642M17.6875 8.46642C18.108 8.61509 18.4721 8.8905 18.7295 9.2547C18.987 9.61891 19.1251 10.054 19.125 10.5V16.25C19.125 16.8219 18.8978 17.3703 18.4934 17.7747C18.0891 18.1791 17.5406 18.4062 16.9687 18.4062H4.03125C3.45938 18.4062 2.91093 18.1791 2.50655 17.7747C2.10218 17.3703 1.875 16.8219 1.875 16.25V10.5C1.875 9.56083 2.47492 8.76254 3.3125 8.46642" stroke="black" stroke-width="0.958333" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                              <span> Reports</span>
                           </div>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li>
                     <a href="<?php echo base_url(); ?>admin/public_holidays" <?php if($active_menu=='public_holidays'){echo 'class="active_menu direct_menu"';}?> >
                        <div class="menu-item-left">
                           <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M8 5.74952V13.9995M14 7.99952V16.2495M14.503 19.7475L19.378 17.3105C19.759 17.1205 20 16.7305 20 16.3045V3.81952C20 2.98352 19.12 2.43952 18.372 2.81352L14.503 4.74752C14.186 4.90652 13.813 4.90652 13.497 4.74752L8.503 2.25152C8.34682 2.17346 8.17461 2.13281 8 2.13281C7.82539 2.13281 7.65318 2.17346 7.497 2.25152L2.622 4.68852C2.24 4.87952 2 5.26952 2 5.69452V18.1795C2 19.0155 2.88 19.5595 3.628 19.1855L7.497 17.2515C7.814 17.0925 8.187 17.0925 8.503 17.2515L13.497 19.7485C13.814 19.9065 14.187 19.9065 14.503 19.7485V19.7475Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Public Holidays</span>
                        </div>
                     </a>
                  </li>
                   <li>
                     <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <div class="menu-item-left">
                           <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8.59372 2.94C8.68372 2.398 9.15372 2 9.70372 2H12.2967C12.8467 2 13.3167 2.398 13.4067 2.94L13.6197 4.221C13.6827 4.595 13.9327 4.907 14.2647 5.091C14.3387 5.131 14.4117 5.174 14.4847 5.218C14.8087 5.414 15.2047 5.475 15.5597 5.342L16.7767 4.886C17.0261 4.79221 17.3007 4.78998 17.5516 4.87971C17.8025 4.96945 18.0134 5.14531 18.1467 5.376L19.4427 7.623C19.5758 7.8537 19.6227 8.12413 19.5751 8.38617C19.5275 8.6482 19.3884 8.88485 19.1827 9.054L18.1797 9.881C17.8867 10.121 17.7417 10.494 17.7487 10.873C17.7503 10.958 17.7503 11.043 17.7487 11.128C17.7417 11.506 17.8867 11.878 18.1787 12.118L19.1837 12.946C19.6077 13.296 19.7177 13.9 19.4437 14.376L18.1457 16.623C18.0126 16.8536 17.8019 17.0296 17.5512 17.1195C17.3005 17.2094 17.0261 17.2074 16.7767 17.114L15.5597 16.658C15.2047 16.525 14.8097 16.586 14.4837 16.782C14.4112 16.8261 14.3379 16.8688 14.2637 16.91C13.9327 17.093 13.6827 17.405 13.6197 17.779L13.4067 19.059C13.3167 19.602 12.8467 20 12.2967 20H9.70272C9.15272 20 8.68272 19.602 8.59272 19.06L8.37972 17.779C8.31772 17.405 8.06772 17.093 7.73572 16.909C7.66157 16.8681 7.58822 16.8258 7.51572 16.782C7.19072 16.586 6.79572 16.525 6.43972 16.658L5.22272 17.114C4.97345 17.2075 4.69908 17.2096 4.44842 17.1199C4.19775 17.0302 3.98703 16.8545 3.85372 16.624L2.55672 14.377C2.42366 14.1463 2.37676 13.8759 2.42437 13.6138C2.47198 13.3518 2.61101 13.1152 2.81672 12.946L3.82072 12.119C4.11272 11.879 4.25772 11.506 4.25072 11.127C4.24915 11.042 4.24915 10.957 4.25072 10.872C4.25772 10.494 4.11272 10.122 3.82072 9.882L2.81672 9.054C2.61126 8.88489 2.47239 8.64843 2.42479 8.38662C2.37719 8.12481 2.42393 7.8546 2.55672 7.624L3.85372 5.377C3.9869 5.14614 4.19773 4.97006 4.44863 4.88014C4.69953 4.79021 4.97421 4.79229 5.22372 4.886L6.43972 5.342C6.79572 5.475 7.19072 5.414 7.51572 5.218C7.58772 5.174 7.66172 5.131 7.73572 5.09C8.06772 4.907 8.31772 4.595 8.37972 4.221L8.59372 2.94Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M14 11C14 11.7956 13.6839 12.5587 13.1213 13.1213C12.5587 13.6839 11.7956 14 11 14C10.2044 14 9.44129 13.6839 8.87868 13.1213C8.31607 12.5587 8 11.7956 8 11C8 10.2044 8.31607 9.44129 8.87868 8.87868C9.44129 8.31607 10.2044 8 11 8C11.7956 8 12.5587 8.31607 13.1213 8.87868C13.6839 9.44129 14 10.2044 14 11V11Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Configuration Menu  </span>
                        </div>
                     </a>
                     <ul class="sub-menu" aria-expanded="false">
                        <li>
                           <a href="<?php echo base_url(); ?>admin/designations"<?php if($active_menu=='designations'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8 5.74952V13.9995M14 7.99952V16.2495M14.503 19.7475L19.378 17.3105C19.759 17.1205 20 16.7305 20 16.3045V3.81952C20 2.98352 19.12 2.43952 18.372 2.81352L14.503 4.74752C14.186 4.90652 13.813 4.90652 13.497 4.74752L8.503 2.25152C8.34682 2.17346 8.17461 2.13281 8 2.13281C7.82539 2.13281 7.65318 2.17346 7.497 2.25152L2.622 4.68852C2.24 4.87952 2 5.26952 2 5.69452V18.1795C2 19.0155 2.88 19.5595 3.628 19.1855L7.497 17.2515C7.814 17.0925 8.187 17.0925 8.503 17.2515L13.497 19.7485C13.814 19.9065 14.187 19.9065 14.503 19.7485V19.7475Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              </svg>
                                 <span> Designations</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/email_id"<?php if($active_menu=='email_id'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M16.153 15.9786C17.3467 16.0794 18.5476 15.9205 19.6782 15.5121C19.7214 14.9622 19.613 14.4109 19.3657 13.922C19.1184 13.4331 18.7422 13.0266 18.2806 12.7495C17.819 12.4724 17.291 12.336 16.7576 12.356C16.2241 12.3761 15.7071 12.5519 15.2663 12.863M16.1521 15.9776L16.153 16.0078C16.153 16.2269 16.1417 16.4431 16.1181 16.6564C14.4081 17.6704 12.4705 18.2024 10.499 18.1991C8.45418 18.1991 6.53466 17.6381 4.87993 16.6564C4.8557 16.431 4.84406 16.2044 4.84506 15.9776M16.153 15.9776C16.1493 14.8738 15.8418 13.7939 15.2663 12.864C14.7554 12.036 14.0508 11.3545 13.2175 10.8826C12.3842 10.4107 11.4492 10.1637 10.499 10.1643C9.54901 10.1638 8.61421 10.4109 7.7811 10.8828C6.94799 11.3547 6.24348 12.0361 5.73274 12.864C5.29193 12.5532 4.77499 12.3776 4.24171 12.3577C3.70843 12.3378 3.18057 12.4742 2.71917 12.7513C2.25778 13.0284 1.88169 13.4348 1.63439 13.9235C1.38709 14.4122 1.27868 14.9633 1.3217 15.513C2.45147 15.9237 3.65267 16.0821 4.84601 15.9776C4.84939 14.8739 5.15662 13.794 5.73179 12.864M13.326 4.32085C13.326 5.09574 13.0282 5.83889 12.498 6.38683C11.9678 6.93476 11.2488 7.24258 10.499 7.24258C9.74927 7.24258 9.03021 6.93476 8.50005 6.38683C7.96989 5.83889 7.67205 5.09574 7.67205 4.32085C7.67205 3.54595 7.96989 2.8028 8.50005 2.25487C9.03021 1.70693 9.74927 1.39911 10.499 1.39911C11.2488 1.39911 11.9678 1.70693 12.498 2.25487C13.0282 2.8028 13.326 3.54595 13.326 4.32085ZM18.98 7.24258C18.98 7.53035 18.9251 7.8153 18.8186 8.08116C18.712 8.34702 18.5559 8.58859 18.359 8.79207C18.1621 8.99555 17.9284 9.15696 17.6711 9.26708C17.4139 9.3772 17.1382 9.43388 16.8597 9.43388C16.5813 9.43388 16.3056 9.3772 16.0484 9.26708C15.7911 9.15696 15.5574 8.99555 15.3605 8.79207C15.1636 8.58859 15.0074 8.34702 14.9009 8.08116C14.7943 7.8153 14.7395 7.53035 14.7395 7.24258C14.7395 6.66141 14.9629 6.10405 15.3605 5.6931C15.7581 5.28215 16.2974 5.05128 16.8597 5.05128C17.4221 5.05128 17.9614 5.28215 18.359 5.6931C18.7566 6.10405 18.98 6.66141 18.98 7.24258ZM6.25856 7.24258C6.25856 7.53035 6.20371 7.8153 6.09716 8.08116C5.99061 8.34702 5.83443 8.58859 5.63755 8.79207C5.44067 8.99555 5.20694 9.15696 4.9497 9.26708C4.69246 9.3772 4.41675 9.43388 4.13832 9.43388C3.85989 9.43388 3.58418 9.3772 3.32694 9.26708C3.0697 9.15696 2.83597 8.99555 2.63908 8.79207C2.4422 8.58859 2.28603 8.34702 2.17947 8.08116C2.07292 7.8153 2.01808 7.53035 2.01808 7.24258C2.01808 6.66141 2.24146 6.10405 2.63908 5.6931C3.03671 5.28215 3.576 5.05128 4.13832 5.05128C4.70064 5.05128 5.23993 5.28215 5.63755 5.6931C6.03517 6.10405 6.25856 6.66141 6.25856 7.24258Z" stroke="black" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                                 <span>Management</span>
                              </div>
                           </a>
                        </li>
                         <li>
                           <a href="<?php echo base_url(); ?>admin/identifications" <?php if($active_menu=='identifications'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M14.75 14.75L12.261 12.261M12.261 12.261C12.5744 11.9476 12.823 11.5755 12.9926 11.1661C13.1622 10.7566 13.2495 10.3177 13.2495 9.8745C13.2495 9.43129 13.1622 8.99241 12.9926 8.58294C12.823 8.17346 12.5744 7.8014 12.261 7.488C11.9476 7.1746 11.5755 6.926 11.1661 6.75639C10.7566 6.58678 10.3177 6.49948 9.8745 6.49948C9.43129 6.49948 8.99241 6.58678 8.58294 6.75639C8.17346 6.926 7.8014 7.1746 7.488 7.488C6.85493 8.12107 6.49927 8.9797 6.49927 9.875C6.49927 10.7703 6.85493 11.6289 7.488 12.262C8.12107 12.8951 8.9797 13.2507 9.875 13.2507C10.7703 13.2507 11.6289 12.8951 12.262 12.262L12.261 12.261ZM20 11C20 12.1819 19.7672 13.3522 19.3149 14.4442C18.8626 15.5361 18.1997 16.5282 17.364 17.364C16.5282 18.1997 15.5361 18.8626 14.4442 19.3149C13.3522 19.7672 12.1819 20 11 20C9.8181 20 8.64778 19.7672 7.55585 19.3149C6.46392 18.8626 5.47177 18.1997 4.63604 17.364C3.80031 16.5282 3.13738 15.5361 2.68508 14.4442C2.23279 13.3522 2 12.1819 2 11C2 8.61305 2.94821 6.32387 4.63604 4.63604C6.32387 2.94821 8.61305 2 11 2C13.3869 2 15.6761 2.94821 17.364 4.63604C19.0518 6.32387 20 8.61305 20 11Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                                 <span>Identification Type</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/clients" <?php if($active_menu=='clients'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M11 7.40122V11.22M11 1C8.73574 3.18965 5.72027 4.39061 2.598 4.34623C2.20074 5.57871 1.99887 6.86779 2 8.16497C2 13.8595 5.824 18.6436 11 20C16.176 18.6436 20 13.8595 20 8.16497C20 6.83096 19.79 5.54786 19.402 4.34623H19.25C16.054 4.34623 13.15 3.07434 11 1V1ZM11 14.2749H11.008V14.2831H11V14.2749Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                                 <span>Client Management</span>
                              </div>
                           </a>
                        </li>
                     </ul>
                  </li>
                  <!-- <li>
                     <a href="<?php echo base_url(); ?>admin/employee_email_id" <?php if($active_menu=='employee_email_id'){echo 'class="active_menu"';}?> ><i class="fa fa-list-alt" aria-hidden="true"></i><span>Employee Assign Email Id's</span></a>
                  </li> -->
                <li>
                    <a href="<?php echo base_url(); ?>admin/certificate_of_service_letter" <?php if($active_menu=='certificate_of_service_letter'){echo 'class="active_menu"';}?> >
                     <div class="menu-item-left">
                           <svg width="21" height="24" viewBox="0 0 21 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M18.0833 13.823V11.3615C18.0833 10.5221 17.7238 9.71711 17.0838 9.12358C16.4438 8.53006 15.5758 8.19662 14.6708 8.19662H13.1541C12.8524 8.19662 12.5631 8.08548 12.3498 7.88764C12.1365 7.6898 12.0166 7.42147 12.0166 7.14168V5.73509C12.0166 4.89572 11.6571 4.09073 11.0171 3.49721C10.3772 2.90369 9.50918 2.57025 8.60413 2.57025H6.70829M6.70829 14.5263H14.2916M6.70829 17.3395H10.5M8.98329 2.57025H4.05413C3.42623 2.57025 2.91663 3.04287 2.91663 3.6252V19.801C2.91663 20.3833 3.42623 20.856 4.05413 20.856H16.9458C17.5737 20.856 18.0833 20.3833 18.0833 19.801V11.0098C18.0833 8.7715 17.1245 6.62487 15.418 5.04214C13.7114 3.45942 11.3968 2.57025 8.98329 2.57025V2.57025Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Certificate Of Service Letter </span>
                     </div>
                     </a>
                </li>
                <li>
                     <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <div class="menu-item-left">
                           <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8.59372 2.94C8.68372 2.398 9.15372 2 9.70372 2H12.2967C12.8467 2 13.3167 2.398 13.4067 2.94L13.6197 4.221C13.6827 4.595 13.9327 4.907 14.2647 5.091C14.3387 5.131 14.4117 5.174 14.4847 5.218C14.8087 5.414 15.2047 5.475 15.5597 5.342L16.7767 4.886C17.0261 4.79221 17.3007 4.78998 17.5516 4.87971C17.8025 4.96945 18.0134 5.14531 18.1467 5.376L19.4427 7.623C19.5758 7.8537 19.6227 8.12413 19.5751 8.38617C19.5275 8.6482 19.3884 8.88485 19.1827 9.054L18.1797 9.881C17.8867 10.121 17.7417 10.494 17.7487 10.873C17.7503 10.958 17.7503 11.043 17.7487 11.128C17.7417 11.506 17.8867 11.878 18.1787 12.118L19.1837 12.946C19.6077 13.296 19.7177 13.9 19.4437 14.376L18.1457 16.623C18.0126 16.8536 17.8019 17.0296 17.5512 17.1195C17.3005 17.2094 17.0261 17.2074 16.7767 17.114L15.5597 16.658C15.2047 16.525 14.8097 16.586 14.4837 16.782C14.4112 16.8261 14.3379 16.8688 14.2637 16.91C13.9327 17.093 13.6827 17.405 13.6197 17.779L13.4067 19.059C13.3167 19.602 12.8467 20 12.2967 20H9.70272C9.15272 20 8.68272 19.602 8.59272 19.06L8.37972 17.779C8.31772 17.405 8.06772 17.093 7.73572 16.909C7.66157 16.8681 7.58822 16.8258 7.51572 16.782C7.19072 16.586 6.79572 16.525 6.43972 16.658L5.22272 17.114C4.97345 17.2075 4.69908 17.2096 4.44842 17.1199C4.19775 17.0302 3.98703 16.8545 3.85372 16.624L2.55672 14.377C2.42366 14.1463 2.37676 13.8759 2.42437 13.6138C2.47198 13.3518 2.61101 13.1152 2.81672 12.946L3.82072 12.119C4.11272 11.879 4.25772 11.506 4.25072 11.127C4.24915 11.042 4.24915 10.957 4.25072 10.872C4.25772 10.494 4.11272 10.122 3.82072 9.882L2.81672 9.054C2.61126 8.88489 2.47239 8.64843 2.42479 8.38662C2.37719 8.12481 2.42393 7.8546 2.55672 7.624L3.85372 5.377C3.9869 5.14614 4.19773 4.97006 4.44863 4.88014C4.69953 4.79021 4.97421 4.79229 5.22372 4.886L6.43972 5.342C6.79572 5.475 7.19072 5.414 7.51572 5.218C7.58772 5.174 7.66172 5.131 7.73572 5.09C8.06772 4.907 8.31772 4.595 8.37972 4.221L8.59372 2.94Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M14 11C14 11.7956 13.6839 12.5587 13.1213 13.1213C12.5587 13.6839 11.7956 14 11 14C10.2044 14 9.44129 13.6839 8.87868 13.1213C8.31607 12.5587 8 11.7956 8 11C8 10.2044 8.31607 9.44129 8.87868 8.87868C9.44129 8.31607 10.2044 8 11 8C11.7956 8 12.5587 8.31607 13.1213 8.87868C13.6839 9.44129 14 10.2044 14 11V11Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Role Management  </span>
                        </div>
                     </a>
                     <ul class="sub-menu" aria-expanded="false">
                        <li>
                           <a href="<?php echo base_url(); ?>admin/roles"<?php if($active_menu=='roles'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8 5.74952V13.9995M14 7.99952V16.2495M14.503 19.7475L19.378 17.3105C19.759 17.1205 20 16.7305 20 16.3045V3.81952C20 2.98352 19.12 2.43952 18.372 2.81352L14.503 4.74752C14.186 4.90652 13.813 4.90652 13.497 4.74752L8.503 2.25152C8.34682 2.17346 8.17461 2.13281 8 2.13281C7.82539 2.13281 7.65318 2.17346 7.497 2.25152L2.622 4.68852C2.24 4.87952 2 5.26952 2 5.69452V18.1795C2 19.0155 2.88 19.5595 3.628 19.1855L7.497 17.2515C7.814 17.0925 8.187 17.0925 8.503 17.2515L13.497 19.7485C13.814 19.9065 14.187 19.9065 14.503 19.7485V19.7475Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              </svg>
                                 <span> Roles</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/role_access"<?php if($active_menu=='role_access'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M16.153 15.9786C17.3467 16.0794 18.5476 15.9205 19.6782 15.5121C19.7214 14.9622 19.613 14.4109 19.3657 13.922C19.1184 13.4331 18.7422 13.0266 18.2806 12.7495C17.819 12.4724 17.291 12.336 16.7576 12.356C16.2241 12.3761 15.7071 12.5519 15.2663 12.863M16.1521 15.9776L16.153 16.0078C16.153 16.2269 16.1417 16.4431 16.1181 16.6564C14.4081 17.6704 12.4705 18.2024 10.499 18.1991C8.45418 18.1991 6.53466 17.6381 4.87993 16.6564C4.8557 16.431 4.84406 16.2044 4.84506 15.9776M16.153 15.9776C16.1493 14.8738 15.8418 13.7939 15.2663 12.864C14.7554 12.036 14.0508 11.3545 13.2175 10.8826C12.3842 10.4107 11.4492 10.1637 10.499 10.1643C9.54901 10.1638 8.61421 10.4109 7.7811 10.8828C6.94799 11.3547 6.24348 12.0361 5.73274 12.864C5.29193 12.5532 4.77499 12.3776 4.24171 12.3577C3.70843 12.3378 3.18057 12.4742 2.71917 12.7513C2.25778 13.0284 1.88169 13.4348 1.63439 13.9235C1.38709 14.4122 1.27868 14.9633 1.3217 15.513C2.45147 15.9237 3.65267 16.0821 4.84601 15.9776C4.84939 14.8739 5.15662 13.794 5.73179 12.864M13.326 4.32085C13.326 5.09574 13.0282 5.83889 12.498 6.38683C11.9678 6.93476 11.2488 7.24258 10.499 7.24258C9.74927 7.24258 9.03021 6.93476 8.50005 6.38683C7.96989 5.83889 7.67205 5.09574 7.67205 4.32085C7.67205 3.54595 7.96989 2.8028 8.50005 2.25487C9.03021 1.70693 9.74927 1.39911 10.499 1.39911C11.2488 1.39911 11.9678 1.70693 12.498 2.25487C13.0282 2.8028 13.326 3.54595 13.326 4.32085ZM18.98 7.24258C18.98 7.53035 18.9251 7.8153 18.8186 8.08116C18.712 8.34702 18.5559 8.58859 18.359 8.79207C18.1621 8.99555 17.9284 9.15696 17.6711 9.26708C17.4139 9.3772 17.1382 9.43388 16.8597 9.43388C16.5813 9.43388 16.3056 9.3772 16.0484 9.26708C15.7911 9.15696 15.5574 8.99555 15.3605 8.79207C15.1636 8.58859 15.0074 8.34702 14.9009 8.08116C14.7943 7.8153 14.7395 7.53035 14.7395 7.24258C14.7395 6.66141 14.9629 6.10405 15.3605 5.6931C15.7581 5.28215 16.2974 5.05128 16.8597 5.05128C17.4221 5.05128 17.9614 5.28215 18.359 5.6931C18.7566 6.10405 18.98 6.66141 18.98 7.24258ZM6.25856 7.24258C6.25856 7.53035 6.20371 7.8153 6.09716 8.08116C5.99061 8.34702 5.83443 8.58859 5.63755 8.79207C5.44067 8.99555 5.20694 9.15696 4.9497 9.26708C4.69246 9.3772 4.41675 9.43388 4.13832 9.43388C3.85989 9.43388 3.58418 9.3772 3.32694 9.26708C3.0697 9.15696 2.83597 8.99555 2.63908 8.79207C2.4422 8.58859 2.28603 8.34702 2.17947 8.08116C2.07292 7.8153 2.01808 7.53035 2.01808 7.24258C2.01808 6.66141 2.24146 6.10405 2.63908 5.6931C3.03671 5.28215 3.576 5.05128 4.13832 5.05128C4.70064 5.05128 5.23993 5.28215 5.63755 5.6931C6.03517 6.10405 6.25856 6.66141 6.25856 7.24258Z" stroke="black" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                                 <span>Role Access</span>
                              </div>
                           </a>
                        </li>
                     </ul>
                     <li>
                     <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <div class="menu-item-left">
                           <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8.59372 2.94C8.68372 2.398 9.15372 2 9.70372 2H12.2967C12.8467 2 13.3167 2.398 13.4067 2.94L13.6197 4.221C13.6827 4.595 13.9327 4.907 14.2647 5.091C14.3387 5.131 14.4117 5.174 14.4847 5.218C14.8087 5.414 15.2047 5.475 15.5597 5.342L16.7767 4.886C17.0261 4.79221 17.3007 4.78998 17.5516 4.87971C17.8025 4.96945 18.0134 5.14531 18.1467 5.376L19.4427 7.623C19.5758 7.8537 19.6227 8.12413 19.5751 8.38617C19.5275 8.6482 19.3884 8.88485 19.1827 9.054L18.1797 9.881C17.8867 10.121 17.7417 10.494 17.7487 10.873C17.7503 10.958 17.7503 11.043 17.7487 11.128C17.7417 11.506 17.8867 11.878 18.1787 12.118L19.1837 12.946C19.6077 13.296 19.7177 13.9 19.4437 14.376L18.1457 16.623C18.0126 16.8536 17.8019 17.0296 17.5512 17.1195C17.3005 17.2094 17.0261 17.2074 16.7767 17.114L15.5597 16.658C15.2047 16.525 14.8097 16.586 14.4837 16.782C14.4112 16.8261 14.3379 16.8688 14.2637 16.91C13.9327 17.093 13.6827 17.405 13.6197 17.779L13.4067 19.059C13.3167 19.602 12.8467 20 12.2967 20H9.70272C9.15272 20 8.68272 19.602 8.59272 19.06L8.37972 17.779C8.31772 17.405 8.06772 17.093 7.73572 16.909C7.66157 16.8681 7.58822 16.8258 7.51572 16.782C7.19072 16.586 6.79572 16.525 6.43972 16.658L5.22272 17.114C4.97345 17.2075 4.69908 17.2096 4.44842 17.1199C4.19775 17.0302 3.98703 16.8545 3.85372 16.624L2.55672 14.377C2.42366 14.1463 2.37676 13.8759 2.42437 13.6138C2.47198 13.3518 2.61101 13.1152 2.81672 12.946L3.82072 12.119C4.11272 11.879 4.25772 11.506 4.25072 11.127C4.24915 11.042 4.24915 10.957 4.25072 10.872C4.25772 10.494 4.11272 10.122 3.82072 9.882L2.81672 9.054C2.61126 8.88489 2.47239 8.64843 2.42479 8.38662C2.37719 8.12481 2.42393 7.8546 2.55672 7.624L3.85372 5.377C3.9869 5.14614 4.19773 4.97006 4.44863 4.88014C4.69953 4.79021 4.97421 4.79229 5.22372 4.886L6.43972 5.342C6.79572 5.475 7.19072 5.414 7.51572 5.218C7.58772 5.174 7.66172 5.131 7.73572 5.09C8.06772 4.907 8.31772 4.595 8.37972 4.221L8.59372 2.94Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M14 11C14 11.7956 13.6839 12.5587 13.1213 13.1213C12.5587 13.6839 11.7956 14 11 14C10.2044 14 9.44129 13.6839 8.87868 13.1213C8.31607 12.5587 8 11.7956 8 11C8 10.2044 8.31607 9.44129 8.87868 8.87868C9.44129 8.31607 10.2044 8 11 8C11.7956 8 12.5587 8.31607 13.1213 8.87868C13.6839 9.44129 14 10.2044 14 11V11Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Roports  </span>
                        </div>
                     </a>
                     <ul class="sub-menu" aria-expanded="false">
                        <li>
                           <a href="<?php echo base_url(); ?>admin/employee_roles"<?php if($active_menu=='employee_roles'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8 5.74952V13.9995M14 7.99952V16.2495M14.503 19.7475L19.378 17.3105C19.759 17.1205 20 16.7305 20 16.3045V3.81952C20 2.98352 19.12 2.43952 18.372 2.81352L14.503 4.74752C14.186 4.90652 13.813 4.90652 13.497 4.74752L8.503 2.25152C8.34682 2.17346 8.17461 2.13281 8 2.13281C7.82539 2.13281 7.65318 2.17346 7.497 2.25152L2.622 4.68852C2.24 4.87952 2 5.26952 2 5.69452V18.1795C2 19.0155 2.88 19.5595 3.628 19.1855L7.497 17.2515C7.814 17.0925 8.187 17.0925 8.503 17.2515L13.497 19.7485C13.814 19.9065 14.187 19.9065 14.503 19.7485V19.7475Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              </svg>
                                 <span> Employee Roles</span>
                              </div>
                           </a>
                        </li>
                  </li>
               </ul>
             <li>
                     <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <div class="menu-item-left">
                           <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8.59372 2.94C8.68372 2.398 9.15372 2 9.70372 2H12.2967C12.8467 2 13.3167 2.398 13.4067 2.94L13.6197 4.221C13.6827 4.595 13.9327 4.907 14.2647 5.091C14.3387 5.131 14.4117 5.174 14.4847 5.218C14.8087 5.414 15.2047 5.475 15.5597 5.342L16.7767 4.886C17.0261 4.79221 17.3007 4.78998 17.5516 4.87971C17.8025 4.96945 18.0134 5.14531 18.1467 5.376L19.4427 7.623C19.5758 7.8537 19.6227 8.12413 19.5751 8.38617C19.5275 8.6482 19.3884 8.88485 19.1827 9.054L18.1797 9.881C17.8867 10.121 17.7417 10.494 17.7487 10.873C17.7503 10.958 17.7503 11.043 17.7487 11.128C17.7417 11.506 17.8867 11.878 18.1787 12.118L19.1837 12.946C19.6077 13.296 19.7177 13.9 19.4437 14.376L18.1457 16.623C18.0126 16.8536 17.8019 17.0296 17.5512 17.1195C17.3005 17.2094 17.0261 17.2074 16.7767 17.114L15.5597 16.658C15.2047 16.525 14.8097 16.586 14.4837 16.782C14.4112 16.8261 14.3379 16.8688 14.2637 16.91C13.9327 17.093 13.6827 17.405 13.6197 17.779L13.4067 19.059C13.3167 19.602 12.8467 20 12.2967 20H9.70272C9.15272 20 8.68272 19.602 8.59272 19.06L8.37972 17.779C8.31772 17.405 8.06772 17.093 7.73572 16.909C7.66157 16.8681 7.58822 16.8258 7.51572 16.782C7.19072 16.586 6.79572 16.525 6.43972 16.658L5.22272 17.114C4.97345 17.2075 4.69908 17.2096 4.44842 17.1199C4.19775 17.0302 3.98703 16.8545 3.85372 16.624L2.55672 14.377C2.42366 14.1463 2.37676 13.8759 2.42437 13.6138C2.47198 13.3518 2.61101 13.1152 2.81672 12.946L3.82072 12.119C4.11272 11.879 4.25772 11.506 4.25072 11.127C4.24915 11.042 4.24915 10.957 4.25072 10.872C4.25772 10.494 4.11272 10.122 3.82072 9.882L2.81672 9.054C2.61126 8.88489 2.47239 8.64843 2.42479 8.38662C2.37719 8.12481 2.42393 7.8546 2.55672 7.624L3.85372 5.377C3.9869 5.14614 4.19773 4.97006 4.44863 4.88014C4.69953 4.79021 4.97421 4.79229 5.22372 4.886L6.43972 5.342C6.79572 5.475 7.19072 5.414 7.51572 5.218C7.58772 5.174 7.66172 5.131 7.73572 5.09C8.06772 4.907 8.31772 4.595 8.37972 4.221L8.59372 2.94Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M14 11C14 11.7956 13.6839 12.5587 13.1213 13.1213C12.5587 13.6839 11.7956 14 11 14C10.2044 14 9.44129 13.6839 8.87868 13.1213C8.31607 12.5587 8 11.7956 8 11C8 10.2044 8.31607 9.44129 8.87868 8.87868C9.44129 8.31607 10.2044 8 11 8C11.7956 8 12.5587 8.31607 13.1213 8.87868C13.6839 9.44129 14 10.2044 14 11V11Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Recruitment</span>
                        </div>
                     </a>
                     <ul class="sub-menu" aria-expanded="false">
                        <li>
                           <a href="<?php echo base_url(); ?>admin/create_job"<?php if($active_menu=='create_job'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8 5.74952V13.9995M14 7.99952V16.2495M14.503 19.7475L19.378 17.3105C19.759 17.1205 20 16.7305 20 16.3045V3.81952C20 2.98352 19.12 2.43952 18.372 2.81352L14.503 4.74752C14.186 4.90652 13.813 4.90652 13.497 4.74752L8.503 2.25152C8.34682 2.17346 8.17461 2.13281 8 2.13281C7.82539 2.13281 7.65318 2.17346 7.497 2.25152L2.622 4.68852C2.24 4.87952 2 5.26952 2 5.69452V18.1795C2 19.0155 2.88 19.5595 3.628 19.1855L7.497 17.2515C7.814 17.0925 8.187 17.0925 8.503 17.2515L13.497 19.7485C13.814 19.9065 14.187 19.9065 14.503 19.7485V19.7475Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              </svg>
                                 <span> Create Job</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/job_position"<?php if($active_menu=='job_position'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8 5.74952V13.9995M14 7.99952V16.2495M14.503 19.7475L19.378 17.3105C19.759 17.1205 20 16.7305 20 16.3045V3.81952C20 2.98352 19.12 2.43952 18.372 2.81352L14.503 4.74752C14.186 4.90652 13.813 4.90652 13.497 4.74752L8.503 2.25152C8.34682 2.17346 8.17461 2.13281 8 2.13281C7.82539 2.13281 7.65318 2.17346 7.497 2.25152L2.622 4.68852C2.24 4.87952 2 5.26952 2 5.69452V18.1795C2 19.0155 2.88 19.5595 3.628 19.1855L7.497 17.2515C7.814 17.0925 8.187 17.0925 8.503 17.2515L13.497 19.7485C13.814 19.9065 14.187 19.9065 14.503 19.7485V19.7475Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              </svg>
                                 <span> Job Positions</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/rate_calculator_config"<?php if($active_menu=='rate_calculator_config'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8 5.74952V13.9995M14 7.99952V16.2495M14.503 19.7475L19.378 17.3105C19.759 17.1205 20 16.7305 20 16.3045V3.81952C20 2.98352 19.12 2.43952 18.372 2.81352L14.503 4.74752C14.186 4.90652 13.813 4.90652 13.497 4.74752L8.503 2.25152C8.34682 2.17346 8.17461 2.13281 8 2.13281C7.82539 2.13281 7.65318 2.17346 7.497 2.25152L2.622 4.68852C2.24 4.87952 2 5.26952 2 5.69452V18.1795C2 19.0155 2.88 19.5595 3.628 19.1855L7.497 17.2515C7.814 17.0925 8.187 17.0925 8.503 17.2515L13.497 19.7485C13.814 19.9065 14.187 19.9065 14.503 19.7485V19.7475Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              </svg>
                                 <span> Rate Calculator Config</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/client_based_rate_config"<?php if($active_menu=='client_based_rate_config'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8 5.74952V13.9995M14 7.99952V16.2495M14.503 19.7475L19.378 17.3105C19.759 17.1205 20 16.7305 20 16.3045V3.81952C20 2.98352 19.12 2.43952 18.372 2.81352L14.503 4.74752C14.186 4.90652 13.813 4.90652 13.497 4.74752L8.503 2.25152C8.34682 2.17346 8.17461 2.13281 8 2.13281C7.82539 2.13281 7.65318 2.17346 7.497 2.25152L2.622 4.68852C2.24 4.87952 2 5.26952 2 5.69452V18.1795C2 19.0155 2.88 19.5595 3.628 19.1855L7.497 17.2515C7.814 17.0925 8.187 17.0925 8.503 17.2515L13.497 19.7485C13.814 19.9065 14.187 19.9065 14.503 19.7485V19.7475Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              </svg>
                                 <span> Client Based Rate Config</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/candidate_based_rate_config"<?php if($active_menu=='candidate_based_rate_config'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8 5.74952V13.9995M14 7.99952V16.2495M14.503 19.7475L19.378 17.3105C19.759 17.1205 20 16.7305 20 16.3045V3.81952C20 2.98352 19.12 2.43952 18.372 2.81352L14.503 4.74752C14.186 4.90652 13.813 4.90652 13.497 4.74752L8.503 2.25152C8.34682 2.17346 8.17461 2.13281 8 2.13281C7.82539 2.13281 7.65318 2.17346 7.497 2.25152L2.622 4.68852C2.24 4.87952 2 5.26952 2 5.69452V18.1795C2 19.0155 2.88 19.5595 3.628 19.1855L7.497 17.2515C7.814 17.0925 8.187 17.0925 8.503 17.2515L13.497 19.7485C13.814 19.9065 14.187 19.9065 14.503 19.7485V19.7475Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              </svg>
                                 <span> Candidate Based Rate Config</span>
                              </div>
                           </a>
                        </li>
                  </li>
               </ul>
               <li>
                     <a href="<?php echo base_url(); ?>admin/notifications" <?php if($active_menu=='notifications'){echo 'class="active_menu direct_menu"';}?> >
                        <div class="menu-item-left">
                           <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M11 7.40122V11.22M11 1C8.73574 3.18965 5.72027 4.39061 2.598 4.34623C2.20074 5.57871 1.99887 6.86779 2 8.16497C2 13.8595 5.824 18.6436 11 20C16.176 18.6436 20 13.8595 20 8.16497C20 6.83096 19.79 5.54786 19.402 4.34623H19.25C16.054 4.34623 13.15 3.07434 11 1V1ZM11 14.2749H11.008V14.2831H11V14.2749Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Notifications</span>
                        </div>
                     </a>  
                  </li>
                  <li>
                     <a href="<?php echo base_url(); ?>admin/claims" <?php if($active_menu=='claims'){echo 'class="active_menu direct_menu"';}?> >
                        <div class="menu-item-left">
                           <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M11 7.40122V11.22M11 1C8.73574 3.18965 5.72027 4.39061 2.598 4.34623C2.20074 5.57871 1.99887 6.86779 2 8.16497C2 13.8595 5.824 18.6436 11 20C16.176 18.6436 20 13.8595 20 8.16497C20 6.83096 19.79 5.54786 19.402 4.34623H19.25C16.054 4.34623 13.15 3.07434 11 1V1ZM11 14.2749H11.008V14.2831H11V14.2749Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Claims</span>
                        </div>
                     </a>  
                  </li>
                  <li>
                     <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <div class="menu-item-left">
                           <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8.59372 2.94C8.68372 2.398 9.15372 2 9.70372 2H12.2967C12.8467 2 13.3167 2.398 13.4067 2.94L13.6197 4.221C13.6827 4.595 13.9327 4.907 14.2647 5.091C14.3387 5.131 14.4117 5.174 14.4847 5.218C14.8087 5.414 15.2047 5.475 15.5597 5.342L16.7767 4.886C17.0261 4.79221 17.3007 4.78998 17.5516 4.87971C17.8025 4.96945 18.0134 5.14531 18.1467 5.376L19.4427 7.623C19.5758 7.8537 19.6227 8.12413 19.5751 8.38617C19.5275 8.6482 19.3884 8.88485 19.1827 9.054L18.1797 9.881C17.8867 10.121 17.7417 10.494 17.7487 10.873C17.7503 10.958 17.7503 11.043 17.7487 11.128C17.7417 11.506 17.8867 11.878 18.1787 12.118L19.1837 12.946C19.6077 13.296 19.7177 13.9 19.4437 14.376L18.1457 16.623C18.0126 16.8536 17.8019 17.0296 17.5512 17.1195C17.3005 17.2094 17.0261 17.2074 16.7767 17.114L15.5597 16.658C15.2047 16.525 14.8097 16.586 14.4837 16.782C14.4112 16.8261 14.3379 16.8688 14.2637 16.91C13.9327 17.093 13.6827 17.405 13.6197 17.779L13.4067 19.059C13.3167 19.602 12.8467 20 12.2967 20H9.70272C9.15272 20 8.68272 19.602 8.59272 19.06L8.37972 17.779C8.31772 17.405 8.06772 17.093 7.73572 16.909C7.66157 16.8681 7.58822 16.8258 7.51572 16.782C7.19072 16.586 6.79572 16.525 6.43972 16.658L5.22272 17.114C4.97345 17.2075 4.69908 17.2096 4.44842 17.1199C4.19775 17.0302 3.98703 16.8545 3.85372 16.624L2.55672 14.377C2.42366 14.1463 2.37676 13.8759 2.42437 13.6138C2.47198 13.3518 2.61101 13.1152 2.81672 12.946L3.82072 12.119C4.11272 11.879 4.25772 11.506 4.25072 11.127C4.24915 11.042 4.24915 10.957 4.25072 10.872C4.25772 10.494 4.11272 10.122 3.82072 9.882L2.81672 9.054C2.61126 8.88489 2.47239 8.64843 2.42479 8.38662C2.37719 8.12481 2.42393 7.8546 2.55672 7.624L3.85372 5.377C3.9869 5.14614 4.19773 4.97006 4.44863 4.88014C4.69953 4.79021 4.97421 4.79229 5.22372 4.886L6.43972 5.342C6.79572 5.475 7.19072 5.414 7.51572 5.218C7.58772 5.174 7.66172 5.131 7.73572 5.09C8.06772 4.907 8.31772 4.595 8.37972 4.221L8.59372 2.94Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              <path d="M14 11C14 11.7956 13.6839 12.5587 13.1213 13.1213C12.5587 13.6839 11.7956 14 11 14C10.2044 14 9.44129 13.6839 8.87868 13.1213C8.31607 12.5587 8 11.7956 8 11C8 10.2044 8.31607 9.44129 8.87868 8.87868C9.44129 8.31607 10.2044 8 11 8C11.7956 8 12.5587 8.31607 13.1213 8.87868C13.6839 9.44129 14 10.2044 14 11V11Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Purchase Orders</span>
                        </div>
                     </a>
                     <ul class="sub-menu" aria-expanded="false">
                          <li>
                           <a href="<?php echo base_url(); ?>admin/nature_of_business"<?php if($active_menu=='nature_of_business'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8 5.74952V13.9995M14 7.99952V16.2495M14.503 19.7475L19.378 17.3105C19.759 17.1205 20 16.7305 20 16.3045V3.81952C20 2.98352 19.12 2.43952 18.372 2.81352L14.503 4.74752C14.186 4.90652 13.813 4.90652 13.497 4.74752L8.503 2.25152C8.34682 2.17346 8.17461 2.13281 8 2.13281C7.82539 2.13281 7.65318 2.17346 7.497 2.25152L2.622 4.68852C2.24 4.87952 2 5.26952 2 5.69452V18.1795C2 19.0155 2.88 19.5595 3.628 19.1855L7.497 17.2515C7.814 17.0925 8.187 17.0925 8.503 17.2515L13.497 19.7485C13.814 19.9065 14.187 19.9065 14.503 19.7485V19.7475Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              </svg>
                                 <span> Nature Of Business</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/eco_system_practice"<?php if($active_menu=='eco_system_practice'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8 5.74952V13.9995M14 7.99952V16.2495M14.503 19.7475L19.378 17.3105C19.759 17.1205 20 16.7305 20 16.3045V3.81952C20 2.98352 19.12 2.43952 18.372 2.81352L14.503 4.74752C14.186 4.90652 13.813 4.90652 13.497 4.74752L8.503 2.25152C8.34682 2.17346 8.17461 2.13281 8 2.13281C7.82539 2.13281 7.65318 2.17346 7.497 2.25152L2.622 4.68852C2.24 4.87952 2 5.26952 2 5.69452V18.1795C2 19.0155 2.88 19.5595 3.628 19.1855L7.497 17.2515C7.814 17.0925 8.187 17.0925 8.503 17.2515L13.497 19.7485C13.814 19.9065 14.187 19.9065 14.503 19.7485V19.7475Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              </svg>
                                 <span> ECO System Practice</span>
                              </div>
                           </a>
                        </li>
                        <li>
                           <a href="<?php echo base_url(); ?>admin/work_orders"<?php if($active_menu=='work_orders'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8 5.74952V13.9995M14 7.99952V16.2495M14.503 19.7475L19.378 17.3105C19.759 17.1205 20 16.7305 20 16.3045V3.81952C20 2.98352 19.12 2.43952 18.372 2.81352L14.503 4.74752C14.186 4.90652 13.813 4.90652 13.497 4.74752L8.503 2.25152C8.34682 2.17346 8.17461 2.13281 8 2.13281C7.82539 2.13281 7.65318 2.17346 7.497 2.25152L2.622 4.68852C2.24 4.87952 2 5.26952 2 5.69452V18.1795C2 19.0155 2.88 19.5595 3.628 19.1855L7.497 17.2515C7.814 17.0925 8.187 17.0925 8.503 17.2515L13.497 19.7485C13.814 19.9065 14.187 19.9065 14.503 19.7485V19.7475Z" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                              </svg>
                                 <span> Work Orders</span>
                              </div>
                           </a>
                        </li>
               <?php } else { ?>
                    <ul class="metismenu list-unstyled" id="side-menu">
                  <li>
                     <a href="<?php echo base_url(); ?>admin/dashboard" class="waves-effect">
                        <div class="menu-item-left">
                           <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M16.1136 8.11364V5.93182C16.1136 5.35316 15.8838 4.79821 15.4746 4.38904C15.0654 3.97987 14.5105 3.75 13.9318 3.75H5.93182C5.35316 3.75 4.79821 3.97987 4.38904 4.38904C3.97987 4.79821 3.75 5.35316 3.75 5.93182V13.9318C3.75 14.5105 3.97987 15.0654 4.38904 15.4746C4.79821 15.8838 5.35316 16.1136 5.93182 16.1136H8.11364M16.1136 8.11364H17.5682C18.1468 8.11364 18.7018 8.34351 19.111 8.75268C19.5201 9.16185 19.75 9.7168 19.75 10.2955V17.5682C19.75 18.1468 19.5201 18.7018 19.111 19.111C18.7018 19.5201 18.1468 19.75 17.5682 19.75H10.2955C9.7168 19.75 9.16185 19.5201 8.75268 19.111C8.34351 18.7018 8.11364 18.1468 8.11364 17.5682V16.1136M16.1136 8.11364H10.2955C9.7168 8.11364 9.16185 8.34351 8.75268 8.75268C8.34351 9.16185 8.11364 9.7168 8.11364 10.2955V16.1136" stroke="black" stroke-linecap="round" stroke-linejoin="round"/>
                           </svg>
                           <span>Dashboard</span>
                        </div>
                     </a>
                  </li>
                  <?php
                     $role_id=$this->session->userdata('role_id');
                     $MenuData=$this->db->query("SELECT t1.`menu_id`, t1.`menu_name`, t1.`menu_icon`, t1.`is_active`, t2.`role_access_id`, t2.`id`, t2.`role_id`, t2.`menu_id` as `m_id`, t2.`sub_menu_name`, t2.`sub_menu_url`, t2.`access`, t2.`read`, t2.`write` FROM `menu` as `t1` LEFT JOIN `role_access` as `t2` ON `t1`.`menu_id` = `t2`.`menu_id` WHERE t2.`role_id`='$role_id' AND (t2.`read`=1 OR t2.`write`=1) GROUP BY t1.`menu_id`")->result_array();

                     foreach($MenuData as $Menu){
                  ?>
                  <li>
                     <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <div class="menu-item-left">
                           <?php echo $Menu['menu_icon']; ?>
                           <span><?php echo $Menu['menu_name']; ?> </span>
                        </div>
                     </a>
                     <ul class="sub-menu" aria-expanded="false">
                        <?php 
                           $type=$this->session->userdata('type');
                           $MId=$Menu['menu_id'];
                           $SubMenuData=$this->db->query("SELECT t1.`sub_menu_id`, t1.`menu_id`, t1.`sub_menu_name`, t1.`sub_menu_url`, t1.`is_active`, t2.`id`, t2.`role_id`, t2.`menu_id` as `m_id`, t2.`sub_menu_name` as sub_menuname, t2.`sub_menu_url` as `sub_menuurl`,  t2.`sub_menu_icon`, t2.`access`, t2.`read`, t2.`write` FROM `sub_menu` as `t1` LEFT JOIN `role_access` as `t2` ON `t1`.`menu_id` = `t2`.`menu_id` WHERE t2.`role_id`='$role_id' AND (t2.`read`=1 OR t2.`write`=1) AND t2.`menu_id`=$MId GROUP BY t2.sub_menu_name")->result_array();
                           foreach($SubMenuData as $SubMenu){
                        ?>
                        <li>
                           <a href="<?php echo base_url(); ?><?php echo $SubMenu['sub_menuurl']; ?>"<?php if($active_menu=='<?php echo $this->uri->segment(2); ?>'){echo 'class="active_menu"';}?> >
                              <div class="menu-item-left">
                                 <?php echo $SubMenu['sub_menu_icon']; ?>
                                 <span><?php echo $SubMenu['sub_menuname']; ?></span>
                              </div>
                           </a>
                        </li>
                        <?php } ?>
                     </ul>
                  </li>
                  <?php } ?>
                  <?php
                        $MenuEmptyData=$this->db->query("SELECT t1.`sub_menu_id`, t1.`menu_id`, t1.`sub_menu_name`, t1.`sub_menu_url`,  t1.`sub_menu_icon`, t1.`is_active`, t2.`id`, t2.`role_id`, t2.`menu_id` as `m_id`, t2.`sub_menu_name` as sub_menuname, t2.`sub_menu_url` as `sub_menuurl`, t2.`access`, t2.`read`, t2.`write` FROM `sub_menu` as `t1` LEFT JOIN `role_access` as `t2` ON `t1`.`sub_menu_name` = `t2`.`sub_menu_name` WHERE t2.`role_id`='$role_id' AND (t2.`read`=1 OR t2.`write`=1) AND t2.`menu_id` IS NULL")->result_array();
                        foreach($MenuEmptyData as $EmptyMenu){
                  ?>
                  <li>
                     <a href="<?php echo base_url(); ?><?php echo $EmptyMenu['sub_menu_url']; ?>" <?php if($active_menu=='<?php echo $this->uri->segment(2); ?>'){echo 'class="active_menu direct_menu"';}?> >
                        <div class="menu-item-left">
                            <?php echo $EmptyMenu['sub_menu_icon']; ?>
                           <span><?php echo $EmptyMenu['sub_menu_name']; ?></span>
                        </div>
                     </a>
                  </li>
                  
                        
               <?php }  } ?>
                
            </div>
            <!-- Sidebar -->
         </div>
      </div>
      <!-- Left Sidebar End -->