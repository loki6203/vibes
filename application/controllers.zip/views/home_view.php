<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Welcome to CodeIgniter 3.1</title>

<body>

    <div id="container">
        <h1>Welcome to CodeIgniter 3.1</h1>
    </div>
</body>

</html>