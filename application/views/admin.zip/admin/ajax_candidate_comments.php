<?php if(!empty($comments)){$i=1;foreach ($comments as $cmnts) { ?>
<div class="previos-comments" style="background-color: #d8d7d7">
  <p><?php echo $i; ?>) Comments: <?php echo $cmnts['comments']; ?></p>
  <p>Date: <?php echo DD_M_YY_h_i_s($cmnts['date']); ?></p>
</div>
<?php $i++;} } ?>